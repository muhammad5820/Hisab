# Hisab – Personal Money Collection Manager

A native offline Android application built with **Kotlin**, **Jetpack Compose (Material 3)**, **Room Database (SQLite)**, **WorkManager**, and **MVVM + Repository** architecture.

## Key Features
- **Dashboard**: Real-time KPIs (Total to Collect, Collected, Outstanding, Total People, Pending, Fully Paid), due/overdue reminders, pending people list, recent payment activity, quick actions, and search.
- **People Management**: Add, view, edit, and delete people with duplicate phone number warnings, search, sort (Recent Activity, Name, Highest/Lowest Balance), and filter (All, Pending, Partially Paid, Fully Paid, Overdue).
- **Exact Monetary Precision**: All amounts are stored and calculated in integer `Long` paise (1 ₹ = 100 paise) and formatted in the Indian numbering system (`₹1,00,000`). Zero floating-point arithmetic is used.
- **Multiple Payments & Validation**: Unlimited partial payments (Cash, UPI, Bank Transfer, Other), chronological history, edit/delete with automatic recalculation, and strict validation against zero/negative/overpayment/rapid duplicate submissions.
- **WhatsApp & SMS Reminders**: Pre-filled customizable reminder messages with Total, Paid, Remaining Balance, and Due Date. Opens WhatsApp (or WhatsApp Business) or the default SMS app directly without claiming automatic sending.
- **Local Reminders**: WorkManager daily checks and manual per-person reminder notifications with Android 13+ `POST_NOTIFICATIONS` handling.
- **Reports & Exports**: Period collection totals, monthly summary, person-wise pending balances, Excel-compatible CSV (UTF-8 BOM), and multi-page `PdfDocument` reports + individual statements shared via `FileProvider`.
- **Backup, Restore & App Lock**: Local JSON backup/restore inside Room transactions, Light/Dark/System theme, 4-digit PIN lock + BiometricPrompt, and double-confirmed data clear.

## Requirements & Build Instructions
- **Android Studio**: Ladybug (2024.2.1) or newer
- **JDK**: Java 17
- **Android SDK**: Compile SDK 35, Min SDK 26 (Android 8.0), Target SDK 35

### Steps to Build & Generate APK
1. Extract `Hisab_Android_Studio_Project.zip` and open the `Hisab/` folder in **Android Studio**.
2. Wait for Gradle Sync to download dependencies (requires internet access for Google Maven & Maven Central).
   - If you prefer building from the command line and have Gradle/Wrapper installed:
     ```bash
     ./gradlew testDebugUnitTest
     ./gradlew assembleDebug
     ```
3. The installable APK will be generated at:
   `app/build/outputs/apk/debug/app-debug.apk`
4. Install on a connected Android 8.0+ device or emulator via Android Studio **Run** or:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

## QA & Testing Checklist
- **Automated Unit Tests**: Run `./gradlew testDebugUnitTest` to execute `HisabCalculationAndValidationTest`, which verifies Scenarios A–D, Indian numbering (`₹1,00,000`), paise parsing, phone normalization, and WhatsApp/SMS message templates.
- **Scenario A**: Add Rahul with `₹10,000` -> Record `₹2,000` payment -> Verify remaining balance is `₹8,000`.
- **Scenario B**: Add `₹3,000` and `₹1,000` payments -> Verify total paid `₹6,000` (60%) and remaining `₹4,000`.
- **Scenario C**: Add Person with `₹5,000` -> Record `₹5,000` payment -> Verify remaining `₹0` and status `Fully Paid`.
- **Scenario D**: On a `₹10,000` record with `₹2,000` + `₹3,000` payments, delete the `₹2,000` payment -> Verify remaining updates to `₹7,000`.
- **Scenario E**: Force-close and reopen the app -> Verify all people, payments, and dashboard totals persist accurately.
- **Messaging & Exports**: Test WhatsApp/SMS composer on a real device, export CSV/PDF from Reports, and test JSON Backup & Restore in Settings.

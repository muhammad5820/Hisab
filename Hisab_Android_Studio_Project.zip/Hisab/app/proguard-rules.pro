# Add project specific ProGuard rules here.
-keep class com.hisab.app.data.local.** { *; }

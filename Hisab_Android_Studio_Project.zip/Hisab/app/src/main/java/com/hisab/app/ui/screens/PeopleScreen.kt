package com.hisab.app.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.hisab.app.data.local.entity.PaymentStatus
import com.hisab.app.data.local.entity.PersonWithPayments
import com.hisab.app.ui.components.PersonSummaryCard
import com.hisab.app.ui.viewmodel.PeopleFilterOption
import com.hisab.app.ui.viewmodel.PeopleSortOption

@Composable
fun PeopleScreen(
    people: List<PersonWithPayments>,
    currencySymbol: String,
    onPersonClick: (Long) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(PeopleFilterOption.ALL) }
    var selectedSort by remember { mutableStateOf(PeopleSortOption.RECENT_ACTIVITY) }
    var showSortMenu by remember { mutableStateOf(false) }

    val displayedPeople = remember(people, searchQuery, selectedFilter, selectedSort) {
        val filtered = people.filter { p ->
            val matchesQuery = searchQuery.isBlank() ||
                p.person.name.contains(searchQuery, ignoreCase = true) ||
                p.person.phoneNumber.contains(searchQuery, ignoreCase = true)

            val matchesFilter = when (selectedFilter) {
                PeopleFilterOption.ALL -> true
                PeopleFilterOption.PENDING -> p.status == PaymentStatus.PENDING
                PeopleFilterOption.PARTIALLY_PAID -> p.status == PaymentStatus.PARTIALLY_PAID
                PeopleFilterOption.FULLY_PAID -> p.status == PaymentStatus.FULLY_PAID
                PeopleFilterOption.OVERDUE -> p.isOverdue()
            }
            matchesQuery && matchesFilter
        }

        when (selectedSort) {
            PeopleSortOption.RECENT_ACTIVITY -> filtered.sortedByDescending { it.lastActivityMillis }
            PeopleSortOption.NAME_ASC -> filtered.sortedBy { it.person.name.lowercase() }
            PeopleSortOption.HIGHEST_BALANCE -> filtered.sortedByDescending { it.remainingBalancePaise }
            PeopleSortOption.LOWEST_BALANCE -> filtered.sortedBy { it.remainingBalancePaise }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search name or phone...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f)
            )
            Box {
                IconButton(onClick = { showSortMenu = true }) {
                    Icon(Icons.AutoMirrored.Filled.Sort, contentDescription = "Sort people")
                }
                DropdownMenu(
                    expanded = showSortMenu,
                    onDismissRequest = { showSortMenu = false }
                ) {
                    PeopleSortOption.entries.forEach { option ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = if (option == selectedSort) "✓ ${option.label}" else option.label
                                )
                            },
                            onClick = {
                                selectedSort = option
                                showSortMenu = false
                            }
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PeopleFilterOption.entries.forEach { filter ->
                FilterChip(
                    selected = selectedFilter == filter,
                    onClick = { selectedFilter = filter },
                    label = { Text(filter.label) }
                )
            }
        }

        if (displayedPeople.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (people.isEmpty()) "No people added yet. Tap + to add someone."
                    else "No matching records found.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(displayedPeople, key = { it.person.id }) { p ->
                    PersonSummaryCard(
                        personWithPayments = p,
                        currencySymbol = currencySymbol,
                        onClick = { onPersonClick(p.person.id) }
                    )
                }
                item { Spacer(Modifier.height(72.dp)) }
            }
        }
    }
}

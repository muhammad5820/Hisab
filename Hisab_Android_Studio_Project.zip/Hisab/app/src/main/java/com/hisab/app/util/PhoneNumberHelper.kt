package com.hisab.app.util

object PhoneNumberHelper {

    /**
     * Extracts digits and normalizes Indian phone numbers to a 10-digit canonical key
     * when possible, for duplicate detection.
     */
    fun canonicalKey(rawPhone: String): String {
        val digits = rawPhone.filter { it.isDigit() }
        return when {
            digits.length == 12 && digits.startsWith("91") -> digits.substring(2)
            digits.length == 11 && digits.startsWith("0") -> digits.substring(1)
            digits.length > 10 -> digits.takeLast(10)
            else -> digits
        }
    }

    fun isValidPhone(rawPhone: String): Boolean {
        val digits = rawPhone.filter { it.isDigit() }
        return digits.length in 10..15
    }

    /**
     * Formats phone number for WhatsApp wa.me / api.whatsapp.com (no '+' sign, includes country code).
     * Defaults to India (+91) for 10-digit numbers.
     */
    fun toWhatsAppDigits(rawPhone: String): String {
        val trimmed = rawPhone.trim()
        val digits = trimmed.filter { it.isDigit() }
        return when {
            trimmed.startsWith("+") -> digits
            digits.length == 10 -> "91$digits"
            digits.length == 11 && digits.startsWith("0") -> "91${digits.substring(1)}"
            else -> digits
        }
    }

    /**
     * Formats phone number for SMS URI (includes '+' prefix).
     */
    fun toE164(rawPhone: String): String {
        val wa = toWhatsAppDigits(rawPhone)
        return if (wa.isNotEmpty()) "+$wa" else rawPhone.trim()
    }

    fun formatForDisplay(rawPhone: String): String {
        val key = canonicalKey(rawPhone)
        return if (key.length == 10) {
            "+91 ${key.substring(0, 5)} ${key.substring(5)}"
        } else {
            rawPhone.trim()
        }
    }
}

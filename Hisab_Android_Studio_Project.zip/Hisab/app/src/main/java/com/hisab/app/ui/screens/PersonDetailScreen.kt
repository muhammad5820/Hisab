package com.hisab.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hisab.app.data.local.entity.PaymentEntity
import com.hisab.app.data.local.entity.PaymentStatus
import com.hisab.app.data.local.entity.PersonWithPayments
import com.hisab.app.ui.components.ConfirmActionDialog
import com.hisab.app.ui.components.MessageComposerDialog
import com.hisab.app.ui.components.PaymentTransactionCard
import com.hisab.app.ui.components.StatusBadge
import com.hisab.app.ui.theme.CollectedGreen
import com.hisab.app.ui.theme.OverdueRed
import com.hisab.app.ui.theme.PendingOrange
import com.hisab.app.ui.theme.WhatsAppGreen
import com.hisab.app.util.DateUtils
import com.hisab.app.util.ExportHelper
import com.hisab.app.util.IndianCurrencyFormatter
import com.hisab.app.util.MessagingHelper
import com.hisab.app.util.MessagingLaunchResult
import com.hisab.app.util.PhoneNumberHelper
import com.hisab.app.worker.ReminderScheduler
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PersonDetailScreen(
    personWithPayments: PersonWithPayments?,
    currencySymbol: String,
    onBack: () -> Unit,
    onEditPerson: (Long) -> Unit,
    onDeletePerson: (PersonWithPayments) -> Unit,
    onRecordPayment: (Long) -> Unit,
    onEditPayment: (PaymentEntity) -> Unit,
    onDeletePayment: (PaymentEntity) -> Unit,
    onPostMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    var showDeletePersonDialog by remember { mutableStateOf(false) }
    var paymentToDelete by remember { mutableStateOf<PaymentEntity?>(null) }
    var messageDialogMode by remember { mutableStateOf<Boolean?>(null) } // true=WhatsApp, false=SMS
    var showReminderDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(personWithPayments?.person?.name ?: "Person Details") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (personWithPayments != null) {
                        IconButton(onClick = {
                            val pdfFile = ExportHelper.generatePersonStatementPdf(
                                context, personWithPayments, currencySymbol
                            )
                            ExportHelper.shareFile(
                                context,
                                pdfFile,
                                "application/pdf",
                                "${personWithPayments.person.name} Statement"
                            )
                        }) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = "Export Statement PDF")
                        }
                        IconButton(onClick = { showDeletePersonDialog = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete person", tint = OverdueRed)
                        }
                    }
                }
            )
        }
    ) { padding ->
        if (personWithPayments == null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Record not found.", style = MaterialTheme.typography.bodyLarge)
            }
            return@Scaffold
        }

        val person = personWithPayments.person
        val sortedPayments = remember(personWithPayments.payments) {
            personWithPayments.payments.sortedByDescending { it.paymentDateMillis }
        }
        val isOverdue = personWithPayments.isOverdue()

        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Profile & Balance Summary Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(person.name, style = MaterialTheme.typography.headlineMedium)
                                Text(
                                    text = PhoneNumberHelper.formatForDisplay(person.phoneNumber),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            StatusBadge(status = personWithPayments.status, isOverdue = isOverdue)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Original", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    IndianCurrencyFormatter.formatPaise(person.totalAmountPaise, currencySymbol),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Paid", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    IndianCurrencyFormatter.formatPaise(personWithPayments.totalPaidPaise, currencySymbol),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = CollectedGreen,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Remaining", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    IndianCurrencyFormatter.formatPaise(personWithPayments.remainingBalancePaise, currencySymbol),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = if (personWithPayments.remainingBalancePaise == 0L) CollectedGreen else PendingOrange,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        LinearProgressIndicator(
                            progress = { personWithPayments.progressFraction },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = if (personWithPayments.status == PaymentStatus.FULLY_PAID) CollectedGreen else MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "${personWithPayments.progressPercent}% collected",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        person.dueDateMillis?.let { due ->
                            Text(
                                text = if (isOverdue) "Overdue since: ${DateUtils.formatDate(due)}" else "Due date: ${DateUtils.formatDate(due)}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (isOverdue) OverdueRed else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        if (!person.notes.isNullOrBlank()) {
                            Text(
                                text = "Notes: ${person.notes}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // 5 Required Action Buttons + Manual Reminder
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onRecordPayment(person.id) },
                        enabled = personWithPayments.remainingBalancePaise > 0L,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            if (personWithPayments.remainingBalancePaise > 0L) "Record Payment"
                            else "Fully Paid"
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { messageDialogMode = true },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = WhatsAppGreen,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("WhatsApp")
                        }
                        FilledTonalButton(
                            onClick = { messageDialogMode = false },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Sms, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Send SMS")
                        }
                    }

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(onClick = { onEditPerson(person.id) }) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Edit Person")
                        }
                        OutlinedButton(onClick = {
                            scope.launch {
                                listState.animateScrollToItem(2)
                            }
                        }) {
                            Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("View Payment History")
                        }
                        if (personWithPayments.remainingBalancePaise > 0L) {
                            OutlinedButton(onClick = { showReminderDialog = true }) {
                                Icon(Icons.Default.Alarm, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Remind Me")
                            }
                        }
                    }
                }
            }

            // Payment History Section
            item {
                Text(
                    text = "Payment History (${sortedPayments.size})",
                    style = MaterialTheme.typography.titleMedium
                )
            }

            if (sortedPayments.isEmpty()) {
                item {
                    Text(
                        text = "No payments recorded yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(sortedPayments, key = { it.id }) { pay ->
                    PaymentTransactionCard(
                        personName = null,
                        payment = pay,
                        currencySymbol = currencySymbol,
                        onEdit = { onEditPayment(pay) },
                        onDelete = { paymentToDelete = pay }
                    )
                }
            }
        }
    }

    messageDialogMode?.let { isWhatsApp ->
        val defaultMsg = remember(personWithPayments) {
            MessagingHelper.buildReminderMessage(personWithPayments, currencySymbol)
        }
        MessageComposerDialog(
            title = if (isWhatsApp) "Send WhatsApp Message" else "Send SMS",
            initialMessage = defaultMsg,
            actionLabel = if (isWhatsApp) "Open WhatsApp" else "Open SMS App",
            onDismiss = { messageDialogMode = null },
            onSend = { editedMsg ->
                val result = if (isWhatsApp) {
                    MessagingHelper.openWhatsApp(context, personWithPayments!!.person.phoneNumber, editedMsg)
                } else {
                    MessagingHelper.openSms(context, personWithPayments!!.person.phoneNumber, editedMsg)
                }
                if (result is MessagingLaunchResult.Error) {
                    onPostMessage(result.message)
                }
                messageDialogMode = null
            }
        )
    }

    if (showDeletePersonDialog && personWithPayments != null) {
        ConfirmActionDialog(
            title = "Delete ${personWithPayments.person.name}?",
            message = "This will permanently delete ${personWithPayments.person.name} and all ${personWithPayments.payments.size} payment record(s).",
            onDismiss = { showDeletePersonDialog = false },
            onConfirm = {
                showDeletePersonDialog = false
                onDeletePerson(personWithPayments)
            }
        )
    }

    paymentToDelete?.let { pay ->
        ConfirmActionDialog(
            title = "Delete Payment?",
            message = "Delete payment of ${IndianCurrencyFormatter.formatPaise(pay.amountPaise, currencySymbol)}? The remaining balance will be recalculated automatically.",
            onDismiss = { paymentToDelete = null },
            onConfirm = {
                onDeletePayment(pay)
                paymentToDelete = null
            }
        )
    }

    if (showReminderDialog && personWithPayments != null) {
        AlertDialog(
            onDismissRequest = { showReminderDialog = false },
            title = { Text("Schedule Local Reminder") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Receive a local notification to follow up with ${personWithPayments.person.name}:")
                    OutlinedButton(
                        onClick = {
                            ReminderScheduler.scheduleManualReminder(context, personWithPayments.person.id, 60L)
                            onPostMessage("Reminder scheduled for 1 hour from now")
                            showReminderDialog = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("In 1 Hour") }
                    OutlinedButton(
                        onClick = {
                            ReminderScheduler.scheduleManualReminder(context, personWithPayments.person.id, 24L * 60L)
                            onPostMessage("Reminder scheduled for tomorrow")
                            showReminderDialog = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Tomorrow (24 Hours)") }
                    OutlinedButton(
                        onClick = {
                            ReminderScheduler.scheduleManualReminder(context, personWithPayments.person.id, 0L)
                            onPostMessage("Reminder notification triggered")
                            showReminderDialog = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Test Notification Now") }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showReminderDialog = false }) { Text("Close") }
            }
        )
    }
}

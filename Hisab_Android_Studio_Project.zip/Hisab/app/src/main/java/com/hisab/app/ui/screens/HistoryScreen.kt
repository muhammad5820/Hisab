package com.hisab.app.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.hisab.app.data.local.entity.PaymentEntity
import com.hisab.app.data.local.entity.PaymentMethod
import com.hisab.app.data.local.entity.PaymentWithPerson
import com.hisab.app.data.local.entity.PersonWithPayments
import com.hisab.app.ui.components.ConfirmActionDialog
import com.hisab.app.ui.components.HisabDatePickerDialog
import com.hisab.app.ui.components.PaymentTransactionCard
import com.hisab.app.ui.viewmodel.HistoryDateFilter
import com.hisab.app.util.DateUtils
import com.hisab.app.util.IndianCurrencyFormatter

@Composable
fun HistoryScreen(
    payments: List<PaymentWithPerson>,
    people: List<PersonWithPayments>,
    currencySymbol: String,
    onEditPayment: (PaymentEntity) -> Unit,
    onDeletePayment: (PaymentEntity) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var dateFilter by remember { mutableStateOf(HistoryDateFilter.ALL) }
    var customStartMillis by remember { mutableStateOf<Long?>(null) }
    var customEndMillis by remember { mutableStateOf<Long?>(null) }
    var pickingCustomStart by remember { mutableStateOf(false) }
    var pickingCustomEnd by remember { mutableStateOf(false) }

    var selectedPersonId by remember { mutableStateOf<Long?>(null) }
    var selectedMethod by remember { mutableStateOf<PaymentMethod?>(null) }
    var showPersonMenu by remember { mutableStateOf(false) }
    var showMethodMenu by remember { mutableStateOf(false) }
    var paymentToDelete by remember { mutableStateOf<PaymentEntity?>(null) }

    val filteredPayments = remember(
        payments, searchQuery, dateFilter, customStartMillis, customEndMillis, selectedPersonId, selectedMethod
    ) {
        val now = System.currentTimeMillis()
        val startToday = DateUtils.startOfTodayMillis(now)
        val startWeek = DateUtils.startOfWeekMillis(now)
        val startMonth = DateUtils.startOfMonthMillis(now)

        payments.filter { item ->
            val p = item.payment
            val matchesQuery = searchQuery.isBlank() ||
                item.person.name.contains(searchQuery, ignoreCase = true) ||
                (p.transactionReference?.contains(searchQuery, ignoreCase = true) == true) ||
                (p.notes?.contains(searchQuery, ignoreCase = true) == true)

            val matchesDate = when (dateFilter) {
                HistoryDateFilter.ALL -> true
                HistoryDateFilter.TODAY -> p.paymentDateMillis >= startToday
                HistoryDateFilter.THIS_WEEK -> p.paymentDateMillis >= startWeek
                HistoryDateFilter.THIS_MONTH -> p.paymentDateMillis >= startMonth
                HistoryDateFilter.CUSTOM -> {
                    val s = customStartMillis ?: Long.MIN_VALUE
                    val e = customEndMillis?.let { DateUtils.endOfDayMillis(it) } ?: Long.MAX_VALUE
                    p.paymentDateMillis in s..e
                }
            }

            val matchesPerson = selectedPersonId == null || item.person.id == selectedPersonId
            val matchesMethod = selectedMethod == null || p.paymentMethod == selectedMethod
            matchesQuery && matchesDate && matchesPerson && matchesMethod
        }
    }

    val totalFilteredPaise = remember(filteredPayments) {
        filteredPayments.sumOf { it.payment.amountPaise }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search person, reference, or notes...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HistoryDateFilter.entries.forEach { f ->
                FilterChip(
                    selected = dateFilter == f,
                    onClick = {
                        dateFilter = f
                        if (f == HistoryDateFilter.CUSTOM) {
                            pickingCustomStart = true
                        }
                    },
                    label = { Text(f.label) }
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(modifier = Modifier.weight(1f)) {
                OutlinedButton(
                    onClick = { showPersonMenu = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val label = people.firstOrNull { it.person.id == selectedPersonId }?.person?.name ?: "All People"
                    Text(label, maxLines = 1)
                }
                DropdownMenu(expanded = showPersonMenu, onDismissRequest = { showPersonMenu = false }) {
                    DropdownMenuItem(
                        text = { Text("All People") },
                        onClick = {
                            selectedPersonId = null
                            showPersonMenu = false
                        }
                    )
                    people.forEach { p ->
                        DropdownMenuItem(
                            text = { Text(p.person.name) },
                            onClick = {
                                selectedPersonId = p.person.id
                                showPersonMenu = false
                            }
                        )
                    }
                }
            }

            Box(modifier = Modifier.weight(1f)) {
                OutlinedButton(
                    onClick = { showMethodMenu = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(selectedMethod?.displayName ?: "All Methods", maxLines = 1)
                }
                DropdownMenu(expanded = showMethodMenu, onDismissRequest = { showMethodMenu = false }) {
                    DropdownMenuItem(
                        text = { Text("All Methods") },
                        onClick = {
                            selectedMethod = null
                            showMethodMenu = false
                        }
                    )
                    PaymentMethod.entries.forEach { m ->
                        DropdownMenuItem(
                            text = { Text(m.displayName) },
                            onClick = {
                                selectedMethod = m
                                showMethodMenu = false
                            }
                        )
                    }
                }
            }
        }

        Text(
            text = "${filteredPayments.size} transaction(s) • Total: ${IndianCurrencyFormatter.formatPaise(totalFilteredPaise, currencySymbol)}",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )

        if (filteredPayments.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No payment transactions match the selected filters.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredPayments, key = { it.payment.id }) { item ->
                    PaymentTransactionCard(
                        personName = item.person.name,
                        payment = item.payment,
                        currencySymbol = currencySymbol,
                        onEdit = { onEditPayment(item.payment) },
                        onDelete = { paymentToDelete = item.payment }
                    )
                }
                item { Spacer(Modifier.height(72.dp)) }
            }
        }
    }

    if (pickingCustomStart) {
        HisabDatePickerDialog(
            initialMillis = customStartMillis,
            onDismiss = { pickingCustomStart = false },
            onConfirm = {
                customStartMillis = it
                pickingCustomStart = false
                pickingCustomEnd = true
            }
        )
    }

    if (pickingCustomEnd) {
        HisabDatePickerDialog(
            initialMillis = customEndMillis ?: customStartMillis,
            onDismiss = { pickingCustomEnd = false },
            onConfirm = {
                customEndMillis = it
                pickingCustomEnd = false
            }
        )
    }

    paymentToDelete?.let { pay ->
        ConfirmActionDialog(
            title = "Delete Payment?",
            message = "Delete payment of ${IndianCurrencyFormatter.formatPaise(pay.amountPaise, currencySymbol)}? The person's balance will recalculate automatically.",
            onDismiss = { paymentToDelete = null },
            onConfirm = {
                onDeletePayment(pay)
                paymentToDelete = null
            }
        )
    }
}

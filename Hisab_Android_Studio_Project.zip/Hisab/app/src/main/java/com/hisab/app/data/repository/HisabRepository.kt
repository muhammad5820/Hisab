package com.hisab.app.data.repository

import androidx.room.withTransaction
import com.hisab.app.data.local.HisabDatabase
import com.hisab.app.data.local.entity.PaymentEntity
import com.hisab.app.data.local.entity.PaymentMethod
import com.hisab.app.data.local.entity.PaymentStatus
import com.hisab.app.data.local.entity.PaymentWithPerson
import com.hisab.app.data.local.entity.PersonEntity
import com.hisab.app.data.local.entity.PersonWithPayments
import com.hisab.app.util.PhoneNumberHelper
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

data class DashboardSummary(
    val totalToCollectPaise: Long = 0L,
    val totalCollectedPaise: Long = 0L,
    val totalOutstandingPaise: Long = 0L,
    val totalPeopleCount: Int = 0,
    val pendingPeopleCount: Int = 0,
    val fullyPaidPeopleCount: Int = 0,
    val overduePeopleCount: Int = 0
)

sealed class OperationResult<out T> {
    data class Success<T>(val data: T) : OperationResult<T>()
    data class Error(val message: String) : OperationResult<Nothing>()
}

class HisabRepository(private val database: HisabDatabase) {

    private val personDao = database.personDao()
    private val paymentDao = database.paymentDao()

    val allPeopleWithPayments: Flow<List<PersonWithPayments>> =
        personDao.observeAllPeopleWithPayments()

    val allPaymentsWithPerson: Flow<List<PaymentWithPerson>> =
        paymentDao.observeAllPaymentsWithPerson()

    val dashboardSummary: Flow<DashboardSummary> = allPeopleWithPayments.map { people ->
        val totalToCollect = people.sumOf { it.person.totalAmountPaise }
        val totalCollected = people.sumOf { it.totalPaidPaise }
        val totalOutstanding = people.sumOf { it.remainingBalancePaise }
        val fullyPaidCount = people.count { it.status == PaymentStatus.FULLY_PAID }
        val pendingCount = people.count { it.remainingBalancePaise > 0L }
        val overdueCount = people.count { it.isOverdue() }

        DashboardSummary(
            totalToCollectPaise = totalToCollect,
            totalCollectedPaise = totalCollected,
            totalOutstandingPaise = totalOutstanding,
            totalPeopleCount = people.size,
            pendingPeopleCount = pendingCount,
            fullyPaidPeopleCount = fullyPaidCount,
            overduePeopleCount = overdueCount
        )
    }

    fun observePerson(personId: Long): Flow<PersonWithPayments?> =
        personDao.observePersonWithPayments(personId)

    suspend fun findDuplicatePhonePerson(phone: String, excludePersonId: Long? = null): PersonEntity? {
        val key = PhoneNumberHelper.canonicalKey(phone)
        if (key.length < 7) return null
        return personDao.getAllPeopleOnce().firstOrNull { existing ->
            existing.id != excludePersonId &&
                PhoneNumberHelper.canonicalKey(existing.phoneNumber) == key
        }
    }

    suspend fun addPerson(
        name: String,
        phoneNumber: String,
        totalAmountPaise: Long,
        createdDateMillis: Long,
        dueDateMillis: Long?,
        notes: String?
    ): OperationResult<Long> {
        val trimmedName = name.trim()
        val trimmedPhone = phoneNumber.trim()
        if (trimmedName.isEmpty()) return OperationResult.Error("Full name is required.")
        if (!PhoneNumberHelper.isValidPhone(trimmedPhone)) {
            return OperationResult.Error("Please enter a valid 10-15 digit phone number.")
        }
        if (totalAmountPaise <= 0L) {
            return OperationResult.Error("Total amount owed must be greater than ₹0.")
        }

        val now = System.currentTimeMillis()
        val entity = PersonEntity(
            name = trimmedName,
            phoneNumber = trimmedPhone,
            totalAmountPaise = totalAmountPaise,
            createdDateMillis = createdDateMillis,
            dueDateMillis = dueDateMillis,
            notes = notes?.trim()?.takeIf { it.isNotEmpty() },
            updatedAtMillis = now
        )
        val id = personDao.insertPerson(entity)
        return OperationResult.Success(id)
    }

    suspend fun updatePerson(
        personId: Long,
        name: String,
        phoneNumber: String,
        totalAmountPaise: Long,
        createdDateMillis: Long,
        dueDateMillis: Long?,
        notes: String?
    ): OperationResult<Unit> {
        val trimmedName = name.trim()
        val trimmedPhone = phoneNumber.trim()
        if (trimmedName.isEmpty()) return OperationResult.Error("Full name is required.")
        if (!PhoneNumberHelper.isValidPhone(trimmedPhone)) {
            return OperationResult.Error("Please enter a valid 10-15 digit phone number.")
        }
        if (totalAmountPaise <= 0L) {
            return OperationResult.Error("Total amount owed must be greater than ₹0.")
        }

        return database.withTransaction {
            val existing = personDao.getPersonById(personId)
                ?: return@withTransaction OperationResult.Error("Person record not found.")
            val totalPaid = paymentDao.getTotalPaidForPerson(personId)
            if (totalAmountPaise < totalPaid) {
                return@withTransaction OperationResult.Error(
                    "Total amount owed cannot be less than the amount already paid."
                )
            }
            personDao.updatePerson(
                existing.copy(
                    name = trimmedName,
                    phoneNumber = trimmedPhone,
                    totalAmountPaise = totalAmountPaise,
                    createdDateMillis = createdDateMillis,
                    dueDateMillis = dueDateMillis,
                    notes = notes?.trim()?.takeIf { it.isNotEmpty() },
                    updatedAtMillis = System.currentTimeMillis()
                )
            )
            OperationResult.Success(Unit)
        }
    }

    suspend fun deletePerson(person: PersonEntity): OperationResult<Unit> {
        personDao.deletePerson(person)
        return OperationResult.Success(Unit)
    }

    suspend fun recordPayment(
        personId: Long,
        amountPaise: Long,
        paymentDateMillis: Long,
        paymentMethod: PaymentMethod,
        transactionReference: String?,
        notes: String?
    ): OperationResult<Long> {
        if (amountPaise <= 0L) {
            return OperationResult.Error("Payment amount must be greater than ₹0.")
        }

        return database.withTransaction {
            val person = personDao.getPersonById(personId)
                ?: return@withTransaction OperationResult.Error("Person record not found.")
            val alreadyPaid = paymentDao.getTotalPaidForPerson(personId)
            val remaining = person.totalAmountPaise - alreadyPaid

            if (remaining <= 0L) {
                return@withTransaction OperationResult.Error("This person has already paid in full.")
            }
            if (amountPaise > remaining) {
                return@withTransaction OperationResult.Error(
                    "Payment cannot exceed the remaining balance."
                )
            }

            // Guard against accidental rapid duplicate submission (same person, amount, method within 3s)
            val now = System.currentTimeMillis()
            val recentPayments = paymentDao.getAllPaymentsOnce()
                .filter { it.personId == personId && (now - it.createdAtMillis) < 3000L }
            if (recentPayments.any { it.amountPaise == amountPaise && it.paymentMethod == paymentMethod }) {
                return@withTransaction OperationResult.Error(
                    "Duplicate payment detected. Please wait a moment before submitting again."
                )
            }

            val payment = PaymentEntity(
                personId = personId,
                amountPaise = amountPaise,
                paymentDateMillis = paymentDateMillis,
                paymentMethod = paymentMethod,
                transactionReference = transactionReference?.trim()?.takeIf { it.isNotEmpty() },
                notes = notes?.trim()?.takeIf { it.isNotEmpty() },
                createdAtMillis = now
            )
            val id = paymentDao.insertPayment(payment)
            personDao.touchPersonUpdated(personId, now)
            OperationResult.Success(id)
        }
    }

    suspend fun updatePayment(
        paymentId: Long,
        amountPaise: Long,
        paymentDateMillis: Long,
        paymentMethod: PaymentMethod,
        transactionReference: String?,
        notes: String?
    ): OperationResult<Unit> {
        if (amountPaise <= 0L) {
            return OperationResult.Error("Payment amount must be greater than ₹0.")
        }

        return database.withTransaction {
            val existing = paymentDao.getPaymentById(paymentId)
                ?: return@withTransaction OperationResult.Error("Payment record not found.")
            val person = personDao.getPersonById(existing.personId)
                ?: return@withTransaction OperationResult.Error("Associated person not found.")
            val otherPaid = paymentDao.getTotalPaidExcluding(existing.personId, paymentId)
            val maxAllowed = person.totalAmountPaise - otherPaid

            if (amountPaise > maxAllowed) {
                return@withTransaction OperationResult.Error(
                    "Updated payment cannot exceed the remaining balance."
                )
            }

            paymentDao.updatePayment(
                existing.copy(
                    amountPaise = amountPaise,
                    paymentDateMillis = paymentDateMillis,
                    paymentMethod = paymentMethod,
                    transactionReference = transactionReference?.trim()?.takeIf { it.isNotEmpty() },
                    notes = notes?.trim()?.takeIf { it.isNotEmpty() }
                )
            )
            personDao.touchPersonUpdated(existing.personId)
            OperationResult.Success(Unit)
        }
    }

    suspend fun deletePayment(payment: PaymentEntity): OperationResult<Unit> {
        database.withTransaction {
            paymentDao.deletePayment(payment)
            personDao.touchPersonUpdated(payment.personId)
        }
        return OperationResult.Success(Unit)
    }

    suspend fun exportBackupJson(): String {
        val people = personDao.getAllPeopleOnce()
        val payments = paymentDao.getAllPaymentsOnce()

        val root = JSONObject().apply {
            put("app", "Hisab")
            put("version", 1)
            put("exportedAtMillis", System.currentTimeMillis())
            put("people", JSONArray().apply {
                people.forEach { p ->
                    put(JSONObject().apply {
                        put("id", p.id)
                        put("name", p.name)
                        put("phoneNumber", p.phoneNumber)
                        put("totalAmountPaise", p.totalAmountPaise)
                        put("createdDateMillis", p.createdDateMillis)
                        if (p.dueDateMillis != null) put("dueDateMillis", p.dueDateMillis)
                        if (p.notes != null) put("notes", p.notes)
                        put("updatedAtMillis", p.updatedAtMillis)
                    })
                }
            })
            put("payments", JSONArray().apply {
                payments.forEach { pay ->
                    put(JSONObject().apply {
                        put("id", pay.id)
                        put("personId", pay.personId)
                        put("amountPaise", pay.amountPaise)
                        put("paymentDateMillis", pay.paymentDateMillis)
                        put("paymentMethod", pay.paymentMethod.name)
                        if (pay.transactionReference != null) {
                            put("transactionReference", pay.transactionReference)
                        }
                        if (pay.notes != null) put("notes", pay.notes)
                        put("createdAtMillis", pay.createdAtMillis)
                    })
                }
            })
        }
        return root.toString(2)
    }

    suspend fun restoreFromBackupJson(jsonString: String): OperationResult<Pair<Int, Int>> {
        return try {
            val root = JSONObject(jsonString)
            if (root.optString("app") != "Hisab") {
                return OperationResult.Error("Invalid backup file: not a Hisab backup.")
            }

            val peopleArray = root.getJSONArray("people")
            val paymentsArray = root.getJSONArray("payments")

            val peopleList = buildList {
                for (i in 0 until peopleArray.length()) {
                    val obj = peopleArray.getJSONObject(i)
                    add(
                        PersonEntity(
                            id = obj.getLong("id"),
                            name = obj.getString("name"),
                            phoneNumber = obj.getString("phoneNumber"),
                            totalAmountPaise = obj.getLong("totalAmountPaise"),
                            createdDateMillis = obj.getLong("createdDateMillis"),
                            dueDateMillis = if (obj.has("dueDateMillis") && !obj.isNull("dueDateMillis")) {
                                obj.getLong("dueDateMillis")
                            } else null,
                            notes = if (obj.has("notes") && !obj.isNull("notes")) obj.getString("notes") else null,
                            updatedAtMillis = obj.optLong("updatedAtMillis", System.currentTimeMillis())
                        )
                    )
                }
            }

            val paymentsList = buildList {
                for (i in 0 until paymentsArray.length()) {
                    val obj = paymentsArray.getJSONObject(i)
                    add(
                        PaymentEntity(
                            id = obj.getLong("id"),
                            personId = obj.getLong("personId"),
                            amountPaise = obj.getLong("amountPaise"),
                            paymentDateMillis = obj.getLong("paymentDateMillis"),
                            paymentMethod = PaymentMethod.fromString(obj.getString("paymentMethod")),
                            transactionReference = if (obj.has("transactionReference") && !obj.isNull("transactionReference")) {
                                obj.getString("transactionReference")
                            } else null,
                            notes = if (obj.has("notes") && !obj.isNull("notes")) obj.getString("notes") else null,
                            createdAtMillis = obj.optLong("createdAtMillis", System.currentTimeMillis())
                        )
                    )
                }
            }

            database.withTransaction {
                paymentDao.deleteAll()
                personDao.deleteAll()
                personDao.insertAll(peopleList)
                paymentDao.insertAll(paymentsList)
            }
            OperationResult.Success(peopleList.size to paymentsList.size)
        } catch (e: Exception) {
            OperationResult.Error("Failed to restore backup: ${e.message ?: "corrupted file"}")
        }
    }

    suspend fun clearAllData() {
        database.withTransaction {
            paymentDao.deleteAll()
            personDao.deleteAll()
        }
    }
}

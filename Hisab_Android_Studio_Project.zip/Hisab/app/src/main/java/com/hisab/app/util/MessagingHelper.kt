package com.hisab.app.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import com.hisab.app.data.local.entity.PersonWithPayments

sealed class MessagingLaunchResult {
    data object Launched : MessagingLaunchResult()
    data class Error(val message: String) : MessagingLaunchResult()
}

object MessagingHelper {

    fun buildReminderMessage(
        personWithPayments: PersonWithPayments,
        currencySymbol: String = "₹"
    ): String {
        val person = personWithPayments.person
        val total = IndianCurrencyFormatter.formatPaise(person.totalAmountPaise, currencySymbol)
        val paid = IndianCurrencyFormatter.formatPaise(personWithPayments.totalPaidPaise, currencySymbol)
        val remaining = IndianCurrencyFormatter.formatPaise(personWithPayments.remainingBalancePaise, currencySymbol)

        return buildString {
            appendLine("Hello ${person.name},")
            appendLine("This is a friendly reminder regarding your pending payment.")
            appendLine("Total Amount: $total")
            appendLine("Amount Paid: $paid")
            appendLine("Remaining Balance: $remaining")
            if (person.dueDateMillis != null) {
                appendLine("Due Date: ${DateUtils.formatDate(person.dueDateMillis)}")
            }
            appendLine("Kindly pay the remaining amount at your convenience.")
            append("Thank you.")
        }
    }

    fun isWhatsAppInstalled(context: Context): Boolean {
        val pm = context.packageManager
        return isPackageInstalled(pm, "com.whatsapp") || isPackageInstalled(pm, "com.whatsapp.w4b")
    }

    private fun isPackageInstalled(pm: PackageManager, packageName: String): Boolean {
        return try {
            pm.getPackageInfo(packageName, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }
    }

    fun openWhatsApp(
        context: Context,
        phoneNumber: String,
        message: String
    ): MessagingLaunchResult {
        val waDigits = PhoneNumberHelper.toWhatsAppDigits(phoneNumber)
        if (waDigits.length < 10) {
            return MessagingLaunchResult.Error("Invalid phone number for WhatsApp.")
        }

        if (!isWhatsAppInstalled(context)) {
            return MessagingLaunchResult.Error(
                "WhatsApp is not installed on this device. You can use SMS instead."
            )
        }

        val encodedText = Uri.encode(message)
        val uri = Uri.parse("https://api.whatsapp.com/send?phone=$waDigits&text=$encodedText")
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val pm = context.packageManager
            when {
                isPackageInstalled(pm, "com.whatsapp") -> setPackage("com.whatsapp")
                isPackageInstalled(pm, "com.whatsapp.w4b") -> setPackage("com.whatsapp.w4b")
            }
        }

        return try {
            context.startActivity(intent)
            MessagingLaunchResult.Launched
        } catch (_: ActivityNotFoundException) {
            MessagingLaunchResult.Error("Unable to open WhatsApp on this device.")
        }
    }

    fun openSms(
        context: Context,
        phoneNumber: String,
        message: String
    ): MessagingLaunchResult {
        val e164 = PhoneNumberHelper.toE164(phoneNumber)
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:${Uri.encode(e164)}")
            putExtra("sms_body", message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            context.startActivity(intent)
            MessagingLaunchResult.Launched
        } catch (_: ActivityNotFoundException) {
            MessagingLaunchResult.Error("No SMS application found on this device.")
        }
    }
}

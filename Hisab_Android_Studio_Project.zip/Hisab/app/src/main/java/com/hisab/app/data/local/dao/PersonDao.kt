package com.hisab.app.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.hisab.app.data.local.entity.PersonEntity
import com.hisab.app.data.local.entity.PersonWithPayments
import kotlinx.coroutines.flow.Flow

@Dao
interface PersonDao {

    @Transaction
    @Query("SELECT * FROM people ORDER BY updatedAtMillis DESC")
    fun observeAllPeopleWithPayments(): Flow<List<PersonWithPayments>>

    @Transaction
    @Query("SELECT * FROM people ORDER BY updatedAtMillis DESC")
    suspend fun getAllPeopleWithPaymentsOnce(): List<PersonWithPayments>

    @Transaction
    @Query("SELECT * FROM people WHERE id = :personId")
    fun observePersonWithPayments(personId: Long): Flow<PersonWithPayments?>

    @Transaction
    @Query("SELECT * FROM people WHERE id = :personId")
    suspend fun getPersonWithPaymentsOnce(personId: Long): PersonWithPayments?

    @Query("SELECT * FROM people WHERE id = :personId")
    suspend fun getPersonById(personId: Long): PersonEntity?

    @Query("SELECT * FROM people")
    suspend fun getAllPeopleOnce(): List<PersonEntity>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertPerson(person: PersonEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(people: List<PersonEntity>)

    @Update
    suspend fun updatePerson(person: PersonEntity)

    @Delete
    suspend fun deletePerson(person: PersonEntity)

    @Query("UPDATE people SET updatedAtMillis = :timestamp WHERE id = :personId")
    suspend fun touchPersonUpdated(personId: Long, timestamp: Long = System.currentTimeMillis())

    @Query("DELETE FROM people")
    suspend fun deleteAll()
}

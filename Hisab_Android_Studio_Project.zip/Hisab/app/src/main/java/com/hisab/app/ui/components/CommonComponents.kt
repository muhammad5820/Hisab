package com.hisab.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hisab.app.data.local.entity.PaymentEntity
import com.hisab.app.data.local.entity.PaymentMethod
import com.hisab.app.data.local.entity.PaymentStatus
import com.hisab.app.data.local.entity.PersonWithPayments
import com.hisab.app.ui.theme.CollectedGreen
import com.hisab.app.ui.theme.CollectedGreenBgDark
import com.hisab.app.ui.theme.CollectedGreenBgLight
import com.hisab.app.ui.theme.OverdueRed
import com.hisab.app.ui.theme.OverdueRedBgDark
import com.hisab.app.ui.theme.OverdueRedBgLight
import com.hisab.app.ui.theme.PendingOrange
import com.hisab.app.ui.theme.PendingOrangeBgDark
import com.hisab.app.ui.theme.PendingOrangeBgLight
import com.hisab.app.util.DateUtils
import com.hisab.app.util.IndianCurrencyFormatter
import com.hisab.app.util.PhoneNumberHelper

@Composable
fun StatusBadge(
    status: PaymentStatus,
    isOverdue: Boolean = false
) {
    val dark = isSystemInDarkTheme()
    val (label, textColor, bgColor) = when {
        isOverdue && status != PaymentStatus.FULLY_PAID -> Triple(
            "Overdue",
            OverdueRed,
            if (dark) OverdueRedBgDark else OverdueRedBgLight
        )
        status == PaymentStatus.FULLY_PAID -> Triple(
            "Fully Paid",
            CollectedGreen,
            if (dark) CollectedGreenBgDark else CollectedGreenBgLight
        )
        status == PaymentStatus.PARTIALLY_PAID -> Triple(
            "Partially Paid",
            PendingOrange,
            if (dark) PendingOrangeBgDark else PendingOrangeBgLight
        )
        else -> Triple(
            "Pending",
            PendingOrange,
            if (dark) PendingOrangeBgDark else PendingOrangeBgLight
        )
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(8.dp)
    ) {
        Text(
            text = label,
            color = textColor,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun PersonSummaryCard(
    personWithPayments: PersonWithPayments,
    currencySymbol: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val person = personWithPayments.person
    val overdue = personWithPayments.isOverdue()
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = person.name,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = PhoneNumberHelper.formatForDisplay(person.phoneNumber),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(8.dp))
                StatusBadge(status = personWithPayments.status, isOverdue = overdue)
            }

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Remaining",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = IndianCurrencyFormatter.formatPaise(personWithPayments.remainingBalancePaise, currencySymbol),
                        style = MaterialTheme.typography.titleMedium,
                        color = if (personWithPayments.remainingBalancePaise == 0L) CollectedGreen else PendingOrange,
                        fontWeight = FontWeight.Bold
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Paid / Total",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${IndianCurrencyFormatter.formatPaise(personWithPayments.totalPaidPaise, currencySymbol)} / ${IndianCurrencyFormatter.formatPaise(person.totalAmountPaise, currencySymbol)}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { personWithPayments.progressFraction },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (personWithPayments.status == PaymentStatus.FULLY_PAID) CollectedGreen else MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            person.dueDateMillis?.let { due ->
                if (personWithPayments.remainingBalancePaise > 0L) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = if (overdue) "Overdue since ${DateUtils.formatDate(due)}" else "Due ${DateUtils.formatDate(due)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (overdue) OverdueRed else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun PaymentTransactionCard(
    personName: String?,
    payment: PaymentEntity,
    currencySymbol: String,
    onEdit: (() -> Unit)? = null,
    onDelete: (() -> Unit)? = null
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                if (!personName.isNullOrBlank()) {
                    Text(
                        text = personName,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text(
                    text = "${DateUtils.formatDate(payment.paymentDateMillis)} • ${payment.paymentMethod.displayName}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (!payment.transactionReference.isNullOrBlank()) {
                    Text(
                        text = "Ref: ${payment.transactionReference}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (!payment.notes.isNullOrBlank()) {
                    Text(
                        text = payment.notes,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "+${IndianCurrencyFormatter.formatPaise(payment.amountPaise, currencySymbol)}",
                    style = MaterialTheme.typography.titleMedium,
                    color = CollectedGreen,
                    fontWeight = FontWeight.Bold
                )
                if (onEdit != null || onDelete != null) {
                    Row {
                        if (onEdit != null) {
                            IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit payment", modifier = Modifier.size(18.dp))
                            }
                        }
                        if (onDelete != null) {
                            IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete payment", tint = OverdueRed, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun RecordOrEditPaymentSheet(
    people: List<PersonWithPayments>,
    initialPersonId: Long?,
    editingPayment: PaymentEntity? = null,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onSubmit: (
        personId: Long,
        amountPaise: Long,
        dateMillis: Long,
        method: PaymentMethod,
        reference: String?,
        notes: String?
    ) -> Unit
) {
    val pendingPeople = remember(people, editingPayment) {
        if (editingPayment != null) people else people.filter { it.remainingBalancePaise > 0L }
    }
    var selectedPersonId by remember {
        mutableStateOf(
            editingPayment?.personId ?: initialPersonId ?: pendingPeople.firstOrNull()?.person?.id
        )
    }
    val selectedPerson = people.firstOrNull { it.person.id == selectedPersonId }
    val maxAllowedPaise = remember(selectedPerson, editingPayment) {
        if (selectedPerson == null) 0L
        else if (editingPayment != null) selectedPerson.remainingBalancePaise + editingPayment.amountPaise
        else selectedPerson.remainingBalancePaise
    }

    var amountText by remember {
        mutableStateOf(
            editingPayment?.let { IndianCurrencyFormatter.paiseToEditableRupees(it.amountPaise) } ?: ""
        )
    }
    var paymentDateMillis by remember {
        mutableLongStateOf(editingPayment?.paymentDateMillis ?: System.currentTimeMillis())
    }
    var selectedMethod by remember {
        mutableStateOf(editingPayment?.paymentMethod ?: PaymentMethod.UPI)
    }
    var referenceText by remember { mutableStateOf(editingPayment?.transactionReference ?: "") }
    var notesText by remember { mutableStateOf(editingPayment?.notes ?: "") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showDatePicker by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = if (editingPayment == null) "Record Payment" else "Edit Payment",
                style = MaterialTheme.typography.titleLarge
            )

            if (pendingPeople.isEmpty()) {
                Text(
                    text = "No people with pending balances found. Add a person first.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                if (editingPayment == null && initialPersonId == null) {
                    Text("Select Person", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        pendingPeople.forEach { p ->
                            FilterChip(
                                selected = p.person.id == selectedPersonId,
                                onClick = {
                                    selectedPersonId = p.person.id
                                    errorMessage = null
                                },
                                label = {
                                    Text("${p.person.name} (${IndianCurrencyFormatter.formatPaise(p.remainingBalancePaise, currencySymbol)})")
                                }
                            )
                        }
                    }
                } else if (selectedPerson != null) {
                    Text(
                        text = "${selectedPerson.person.name} • Max allowed: ${IndianCurrencyFormatter.formatPaise(maxAllowedPaise, currencySymbol)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it
                        errorMessage = null
                    },
                    label = { Text("Payment Amount ($currencySymbol) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        if (maxAllowedPaise > 0L) {
                            TextButton(onClick = {
                                amountText = IndianCurrencyFormatter.paiseToEditableRupees(maxAllowedPaise)
                                errorMessage = null
                            }) {
                                Text("Full")
                            }
                        }
                    }
                )

                OutlinedButton(
                    onClick = { showDatePicker = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Payment Date: ${DateUtils.formatDate(paymentDateMillis)}")
                }

                Text("Payment Method", style = MaterialTheme.typography.labelMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PaymentMethod.entries.forEach { method ->
                        FilterChip(
                            selected = selectedMethod == method,
                            onClick = { selectedMethod = method },
                            label = { Text(method.displayName) }
                        )
                    }
                }

                OutlinedTextField(
                    value = referenceText,
                    onValueChange = { referenceText = it },
                    label = { Text("Transaction Reference (Optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("Notes (Optional)") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = OverdueRed,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                Button(
                    onClick = {
                        val pid = selectedPersonId
                        if (pid == null) {
                            errorMessage = "Please select a person."
                            return@Button
                        }
                        val parsedPaise = IndianCurrencyFormatter.parseRupeesToPaise(amountText)
                        if (parsedPaise == null || parsedPaise <= 0L) {
                            errorMessage = "Enter a valid amount greater than 0."
                            return@Button
                        }
                        if (parsedPaise > maxAllowedPaise) {
                            errorMessage = "Amount cannot exceed remaining balance (${IndianCurrencyFormatter.formatPaise(maxAllowedPaise, currencySymbol)})."
                            return@Button
                        }
                        onSubmit(pid, parsedPaise, paymentDateMillis, selectedMethod, referenceText, notesText)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(if (editingPayment == null) "Save Payment" else "Update Payment")
                }
            }
        }
    }

    if (showDatePicker) {
        HisabDatePickerDialog(
            initialMillis = paymentDateMillis,
            onDismiss = { showDatePicker = false },
            onConfirm = {
                paymentDateMillis = it
                showDatePicker = false
            }
        )
    }
}

@Composable
fun MessageComposerDialog(
    title: String,
    initialMessage: String,
    actionLabel: String,
    onDismiss: () -> Unit,
    onSend: (String) -> Unit
) {
    var message by remember { mutableStateOf(initialMessage) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Review or edit the reminder message before opening the app to send:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 6,
                    maxLines = 10
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSend(message) },
                enabled = message.isNotBlank()
            ) {
                Text(actionLabel)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun ConfirmActionDialog(
    title: String,
    message: String,
    confirmLabel: String = "Delete",
    isDestructive: Boolean = true,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = if (isDestructive) {
            { Icon(Icons.Default.Warning, contentDescription = null, tint = OverdueRed) }
        } else null,
        title = { Text(title) },
        text = { Text(message) },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = if (isDestructive) {
                    ButtonDefaults.buttonColors(containerColor = OverdueRed, contentColor = Color.White)
                } else {
                    ButtonDefaults.buttonColors()
                }
            ) {
                Text(confirmLabel)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HisabDatePickerDialog(
    initialMillis: Long?,
    onDismiss: () -> Unit,
    onConfirm: (Long) -> Unit
) {
    val state = rememberDatePickerState(initialSelectedDateMillis = initialMillis ?: System.currentTimeMillis())
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                state.selectedDateMillis?.let(onConfirm) ?: onDismiss()
            }) { Text("OK") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    ) {
        DatePicker(state = state)
    }
}

package com.hisab.app.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class PaymentMethod(val displayName: String) {
    CASH("Cash"),
    UPI("UPI"),
    BANK_TRANSFER("Bank Transfer"),
    OTHER("Other");

    companion object {
        fun fromString(value: String): PaymentMethod =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) || it.displayName.equals(value, ignoreCase = true) }
                ?: OTHER
    }
}

@Entity(
    tableName = "payments",
    foreignKeys = [
        ForeignKey(
            entity = PersonEntity::class,
            parentColumns = ["id"],
            childColumns = ["personId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["personId"]), Index(value = ["paymentDateMillis"])]
)
data class PaymentEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val personId: Long,
    val amountPaise: Long,
    val paymentDateMillis: Long,
    val paymentMethod: PaymentMethod,
    val transactionReference: String? = null,
    val notes: String? = null,
    val createdAtMillis: Long = System.currentTimeMillis()
)

package com.hisab.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.hisab.app.data.local.entity.PersonEntity
import com.hisab.app.ui.components.HisabDatePickerDialog
import com.hisab.app.ui.theme.OverdueRed
import com.hisab.app.ui.theme.PendingOrange
import com.hisab.app.util.DateUtils
import com.hisab.app.util.IndianCurrencyFormatter
import com.hisab.app.util.PhoneNumberHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditPersonScreen(
    existingPerson: PersonEntity?,
    totalAlreadyPaidPaise: Long = 0L,
    currencySymbol: String,
    checkDuplicatePhone: suspend (String, Long?) -> PersonEntity?,
    onSave: (
        name: String,
        phone: String,
        totalAmountPaise: Long,
        createdDateMillis: Long,
        dueDateMillis: Long?,
        notes: String?
    ) -> Unit,
    onBack: () -> Unit
) {
    var name by remember(existingPerson) { mutableStateOf(existingPerson?.name ?: "") }
    var phone by remember(existingPerson) { mutableStateOf(existingPerson?.phoneNumber ?: "") }
    var amountText by remember(existingPerson) {
        mutableStateOf(
            existingPerson?.let { IndianCurrencyFormatter.paiseToEditableRupees(it.totalAmountPaise) } ?: ""
        )
    }
    var createdDateMillis by remember(existingPerson) {
        mutableLongStateOf(existingPerson?.createdDateMillis ?: System.currentTimeMillis())
    }
    var dueDateMillis by remember(existingPerson) {
        mutableStateOf(existingPerson?.dueDateMillis)
    }
    var notes by remember(existingPerson) { mutableStateOf(existingPerson?.notes ?: "") }

    var duplicatePerson by remember { mutableStateOf<PersonEntity?>(null) }
    var errorText by remember { mutableStateOf<String?>(null) }
    var showCreatedPicker by remember { mutableStateOf(false) }
    var showDuePicker by remember { mutableStateOf(false) }

    LaunchedEffect(phone, existingPerson?.id) {
        duplicatePerson = if (PhoneNumberHelper.canonicalKey(phone).length >= 10) {
            checkDuplicatePhone(phone, existingPerson?.id)
        } else {
            null
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (existingPerson == null) "Add Person" else "Edit Person") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = {
                    name = it
                    errorText = null
                },
                label = { Text("Full Name *") },
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = phone,
                onValueChange = {
                    phone = it
                    errorText = null
                },
                label = { Text("Phone Number * (e.g., 9876543210)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            duplicatePerson?.let { dup ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = PendingOrange.copy(alpha = 0.12f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = PendingOrange)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "This phone number already belongs to ${dup.name}.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = PendingOrange
                        )
                    }
                }
            }

            OutlinedTextField(
                value = amountText,
                onValueChange = {
                    amountText = it
                    errorText = null
                },
                label = { Text("Total Amount Owed ($currencySymbol) *") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                supportingText = if (existingPerson != null && totalAlreadyPaidPaise > 0L) {
                    {
                        Text("Already paid: ${IndianCurrencyFormatter.formatPaise(totalAlreadyPaidPaise, currencySymbol)}")
                    }
                } else null
            )

            OutlinedButton(
                onClick = { showCreatedPicker = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Entry Date: ${DateUtils.formatDate(createdDateMillis)}")
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { showDuePicker = true },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = dueDateMillis?.let { "Due Date: ${DateUtils.formatDate(it)}" }
                            ?: "Set Due Date (Optional)"
                    )
                }
                if (dueDateMillis != null) {
                    IconButton(onClick = { dueDateMillis = null }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear due date")
                    }
                }
            }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Description or Notes (Optional)") },
                minLines = 3,
                maxLines = 5,
                modifier = Modifier.fillMaxWidth()
            )

            if (errorText != null) {
                Text(
                    text = errorText!!,
                    color = OverdueRed,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Spacer(Modifier.height(6.dp))

            Button(
                onClick = {
                    val trimmedName = name.trim()
                    if (trimmedName.isEmpty()) {
                        errorText = "Full name is required."
                        return@Button
                    }
                    if (!PhoneNumberHelper.isValidPhone(phone)) {
                        errorText = "Enter a valid 10-15 digit phone number."
                        return@Button
                    }
                    val paise = IndianCurrencyFormatter.parseRupeesToPaise(amountText)
                    if (paise == null || paise <= 0L) {
                        errorText = "Enter a valid amount greater than 0."
                        return@Button
                    }
                    if (existingPerson != null && paise < totalAlreadyPaidPaise) {
                        errorText = "Total amount cannot be less than already paid (${IndianCurrencyFormatter.formatPaise(totalAlreadyPaidPaise, currencySymbol)})."
                        return@Button
                    }
                    onSave(trimmedName, phone.trim(), paise, createdDateMillis, dueDateMillis, notes)
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(if (existingPerson == null) "Save Person" else "Update Person")
            }
        }
    }

    if (showCreatedPicker) {
        HisabDatePickerDialog(
            initialMillis = createdDateMillis,
            onDismiss = { showCreatedPicker = false },
            onConfirm = {
                createdDateMillis = it
                showCreatedPicker = false
            }
        )
    }

    if (showDuePicker) {
        HisabDatePickerDialog(
            initialMillis = dueDateMillis ?: System.currentTimeMillis(),
            onDismiss = { showDuePicker = false },
            onConfirm = {
                dueDateMillis = it
                showDuePicker = false
            }
        )
    }
}

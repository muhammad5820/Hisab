package com.hisab.app.util

import java.math.BigDecimal

object IndianCurrencyFormatter {

    fun formatPaise(
        paise: Long,
        symbol: String = "₹",
        forceDecimals: Boolean = false
    ): String {
        val isNegative = paise < 0L
        val absPaise = if (isNegative) -paise else paise
        val rupees = absPaise / 100L
        val remPaise = (absPaise % 100L).toInt()

        val formattedRupees = formatIndianInteger(rupees)
        val decimalPart = if (forceDecimals || remPaise != 0) {
            ".%02d".format(remPaise)
        } else {
            ""
        }
        val sign = if (isNegative) "-" else ""
        return "$sign$symbol$formattedRupees$decimalPart"
    }

    fun formatIndianInteger(value: Long): String {
        val str = value.toString()
        if (str.length <= 3) return str
        val lastThree = str.substring(str.length - 3)
        val remaining = str.substring(0, str.length - 3)
        val grouped = StringBuilder()
        var count = 0
        for (i in remaining.length - 1 downTo 0) {
            grouped.append(remaining[i])
            count++
            if (count % 2 == 0 && i != 0) {
                grouped.append(',')
            }
        }
        return grouped.reverse().toString() + "," + lastThree
    }

    /**
     * Parses a user-entered rupee string (e.g. "10,000", "2500.50", "₹1,00,000")
     * into exact integer paise without floating-point arithmetic.
     * Returns null if invalid or negative.
     */
    fun parseRupeesToPaise(rawInput: String): Long? {
        val cleaned = rawInput
            .trim()
            .replace("₹", "")
            .replace("INR", "", ignoreCase = true)
            .replace(",", "")
            .replace(" ", "")

        if (cleaned.isEmpty()) return null
        if (!Regex("^\\d+(\\.\\d{1,2})?$").matches(cleaned)) return null

        return try {
            val bd = BigDecimal(cleaned).movePointRight(2)
            bd.longValueExact()
        } catch (_: Exception) {
            null
        }
    }

    fun paiseToEditableRupees(paise: Long): String {
        val rupees = paise / 100L
        val rem = (paise % 100L).toInt()
        return if (rem == 0) rupees.toString() else "$rupees.${"%02d".format(rem)}"
    }
}

package com.hisab.app.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateUtils {
    private val dateFormatter = SimpleDateFormat("dd MMM yyyy", Locale("en", "IN"))
    private val dateTimeFormatter = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale("en", "IN"))
    private val monthYearFormatter = SimpleDateFormat("MMM yyyy", Locale("en", "IN"))
    private val fileTimestampFormatter = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)

    fun formatDate(millis: Long): String = dateFormatter.format(Date(millis))

    fun formatDateTime(millis: Long): String = dateTimeFormatter.format(Date(millis))

    fun formatMonthYear(millis: Long): String = monthYearFormatter.format(Date(millis))

    fun formatFileTimestamp(millis: Long = System.currentTimeMillis()): String =
        fileTimestampFormatter.format(Date(millis))

    fun startOfTodayMillis(nowMillis: Long = System.currentTimeMillis()): Long {
        return Calendar.getInstance().apply {
            timeInMillis = nowMillis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    fun endOfDayMillis(dayMillis: Long): Long {
        return Calendar.getInstance().apply {
            timeInMillis = dayMillis
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }.timeInMillis
    }

    fun startOfWeekMillis(nowMillis: Long = System.currentTimeMillis()): Long {
        return Calendar.getInstance().apply {
            timeInMillis = nowMillis
            set(Calendar.DAY_OF_WEEK, firstDayOfWeek)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    fun startOfMonthMillis(nowMillis: Long = System.currentTimeMillis()): Long {
        return Calendar.getInstance().apply {
            timeInMillis = nowMillis
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }
}

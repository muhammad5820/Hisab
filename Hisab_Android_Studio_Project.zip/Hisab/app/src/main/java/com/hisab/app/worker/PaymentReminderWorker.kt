package com.hisab.app.worker

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.hisab.app.MainActivity
import com.hisab.app.R
import com.hisab.app.data.local.HisabDatabase
import com.hisab.app.data.preferences.AppPreferences
import com.hisab.app.util.IndianCurrencyFormatter
import java.util.concurrent.TimeUnit

class PaymentReminderWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val prefs = AppPreferences(applicationContext)
        val settings = prefs.settings.value
        if (!settings.notificationsEnabled) return Result.success()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                applicationContext,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return Result.success()
        }

        val db = HisabDatabase.getInstance(applicationContext)
        val symbol = settings.currencyDisplay.symbol
        val targetPersonId = inputData.getLong(KEY_PERSON_ID, -1L)

        if (targetPersonId > 0L) {
            val person = db.personDao().getPersonWithPaymentsOnce(targetPersonId)
            if (person != null && person.remainingBalancePaise > 0L) {
                val amountStr = IndianCurrencyFormatter.formatPaise(person.remainingBalancePaise, symbol)
                postNotification(
                    notificationId = (2000 + targetPersonId).toInt(),
                    title = "Payment Reminder: ${person.person.name}",
                    body = "Pending balance of $amountStr. Tap to open Hisab and send WhatsApp/SMS.",
                    personId = person.person.id
                )
            }
            return Result.success()
        }

        val allPeople = db.personDao().getAllPeopleWithPaymentsOnce()
        val overdue = allPeople.filter { it.isOverdue() }
        val dueSoon = allPeople.filter { it.isDueSoon() }

        if (overdue.isNotEmpty()) {
            val totalOverdue = overdue.sumOf { it.remainingBalancePaise }
            val names = overdue.take(3).joinToString(", ") { it.person.name }
            val extra = if (overdue.size > 3) " +${overdue.size - 3} more" else ""
            postNotification(
                notificationId = 1001,
                title = "${overdue.size} Overdue Payment${if (overdue.size > 1) "s" else ""}",
                body = "$names$extra — Total ${IndianCurrencyFormatter.formatPaise(totalOverdue, symbol)} pending.",
                personId = if (overdue.size == 1) overdue.first().person.id else -1L
            )
        } else if (dueSoon.isNotEmpty()) {
            val totalSoon = dueSoon.sumOf { it.remainingBalancePaise }
            postNotification(
                notificationId = 1002,
                title = "${dueSoon.size} Upcoming Payment Due",
                body = "Total ${IndianCurrencyFormatter.formatPaise(totalSoon, symbol)} due within 3 days.",
                personId = if (dueSoon.size == 1) dueSoon.first().person.id else -1L
            )
        }

        return Result.success()
    }

    private fun postNotification(
        notificationId: Int,
        title: String,
        body: String,
        personId: Long
    ) {
        ReminderScheduler.ensureNotificationChannel(applicationContext)
        val intent = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (personId > 0L) putExtra(EXTRA_PERSON_ID, personId)
        }
        val pendingIntent = PendingIntent.getActivity(
            applicationContext,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        NotificationManagerCompat.from(applicationContext).notify(notificationId, notification)
    }

    companion object {
        const val CHANNEL_ID = "hisab_payment_reminders"
        const val KEY_PERSON_ID = "person_id"
        const val EXTRA_PERSON_ID = "extra_person_id"
    }
}

object ReminderScheduler {
    private const val DAILY_WORK_NAME = "hisab_daily_payment_reminder"

    fun ensureNotificationChannel(context: Context) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            PaymentReminderWorker.CHANNEL_ID,
            "Payment Reminders",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Local reminders for overdue and upcoming collections in Hisab"
        }
        manager.createNotificationChannel(channel)
    }

    fun scheduleDailyCheck(context: Context) {
        val request = PeriodicWorkRequestBuilder<PaymentReminderWorker>(24, TimeUnit.HOURS)
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            DAILY_WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    fun scheduleManualReminder(context: Context, personId: Long, delayMinutes: Long) {
        val request = OneTimeWorkRequestBuilder<PaymentReminderWorker>()
            .setInitialDelay(delayMinutes.coerceAtLeast(0L), TimeUnit.MINUTES)
            .setInputData(workDataOf(PaymentReminderWorker.KEY_PERSON_ID to personId))
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            "manual_reminder_$personId",
            ExistingWorkPolicy.REPLACE,
            request
        )
    }

    fun triggerImmediateCheck(context: Context) {
        val request = OneTimeWorkRequestBuilder<PaymentReminderWorker>().build()
        WorkManager.getInstance(context).enqueue(request)
    }
}

package com.hisab.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "people")
data class PersonEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val name: String,
    val phoneNumber: String,
    val totalAmountPaise: Long,
    val createdDateMillis: Long,
    val dueDateMillis: Long? = null,
    val notes: String? = null,
    val updatedAtMillis: Long = System.currentTimeMillis()
)

package com.hisab.app.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.hisab.app.data.local.entity.PaymentWithPerson
import com.hisab.app.data.local.entity.PersonWithPayments
import java.io.File
import java.io.FileOutputStream

object ExportHelper {

    private const val APP_TITLE = "HISAB – Personal Money Collection Manager"

    fun generateFullReportCsv(
        people: List<PersonWithPayments>,
        payments: List<PaymentWithPerson>,
        currencySymbol: String = "₹"
    ): String {
        val sb = StringBuilder()
        // UTF-8 BOM for Excel compatibility with ₹ symbol
        sb.append('\uFEFF')
        sb.appendLine(csvRow(listOf(APP_TITLE)))
        sb.appendLine(csvRow(listOf("Generated On", DateUtils.formatDateTime(System.currentTimeMillis()))))
        sb.appendLine()

        val totalOwed = people.sumOf { it.person.totalAmountPaise }
        val totalPaid = people.sumOf { it.totalPaidPaise }
        val totalPending = people.sumOf { it.remainingBalancePaise }

        sb.appendLine(csvRow(listOf("SUMMARY")))
        sb.appendLine(csvRow(listOf("Total Amount to Collect", IndianCurrencyFormatter.formatPaise(totalOwed, currencySymbol))))
        sb.appendLine(csvRow(listOf("Total Collected", IndianCurrencyFormatter.formatPaise(totalPaid, currencySymbol))))
        sb.appendLine(csvRow(listOf("Total Outstanding", IndianCurrencyFormatter.formatPaise(totalPending, currencySymbol))))
        sb.appendLine(csvRow(listOf("Total People", people.size.toString())))
        sb.appendLine()

        sb.appendLine(csvRow(listOf("PERSON-WISE LEDGER")))
        sb.appendLine(
            csvRow(
                listOf(
                    "Name",
                    "Phone Number",
                    "Original Amount",
                    "Total Paid",
                    "Remaining Balance",
                    "Status",
                    "Due Date",
                    "Notes"
                )
            )
        )
        people.forEach { p ->
            sb.appendLine(
                csvRow(
                    listOf(
                        p.person.name,
                        PhoneNumberHelper.formatForDisplay(p.person.phoneNumber),
                        IndianCurrencyFormatter.formatPaise(p.person.totalAmountPaise, currencySymbol),
                        IndianCurrencyFormatter.formatPaise(p.totalPaidPaise, currencySymbol),
                        IndianCurrencyFormatter.formatPaise(p.remainingBalancePaise, currencySymbol),
                        p.status.label,
                        p.person.dueDateMillis?.let { DateUtils.formatDate(it) } ?: "-",
                        p.person.notes.orEmpty()
                    )
                )
            )
        }

        sb.appendLine()
        sb.appendLine(csvRow(listOf("ALL PAYMENT TRANSACTIONS")))
        sb.appendLine(
            csvRow(
                listOf(
                    "Date",
                    "Person Name",
                    "Phone Number",
                    "Amount Paid",
                    "Method",
                    "Reference",
                    "Notes"
                )
            )
        )
        payments.forEach { item ->
            sb.appendLine(
                csvRow(
                    listOf(
                        DateUtils.formatDate(item.payment.paymentDateMillis),
                        item.person.name,
                        PhoneNumberHelper.formatForDisplay(item.person.phoneNumber),
                        IndianCurrencyFormatter.formatPaise(item.payment.amountPaise, currencySymbol),
                        item.payment.paymentMethod.displayName,
                        item.payment.transactionReference.orEmpty(),
                        item.payment.notes.orEmpty()
                    )
                )
            )
        }
        return sb.toString()
    }

    fun generatePersonStatementCsv(
        personWithPayments: PersonWithPayments,
        currencySymbol: String = "₹"
    ): String {
        val person = personWithPayments.person
        val sb = StringBuilder()
        sb.append('\uFEFF')
        sb.appendLine(csvRow(listOf(APP_TITLE)))
        sb.appendLine(csvRow(listOf("Individual Payment Statement")))
        sb.appendLine(csvRow(listOf("Generated On", DateUtils.formatDateTime(System.currentTimeMillis()))))
        sb.appendLine()
        sb.appendLine(csvRow(listOf("Person Name", person.name)))
        sb.appendLine(csvRow(listOf("Phone Number", PhoneNumberHelper.formatForDisplay(person.phoneNumber))))
        sb.appendLine(csvRow(listOf("Original Amount", IndianCurrencyFormatter.formatPaise(person.totalAmountPaise, currencySymbol))))
        sb.appendLine(csvRow(listOf("Total Payments Received", IndianCurrencyFormatter.formatPaise(personWithPayments.totalPaidPaise, currencySymbol))))
        sb.appendLine(csvRow(listOf("Remaining Balance", IndianCurrencyFormatter.formatPaise(personWithPayments.remainingBalancePaise, currencySymbol))))
        sb.appendLine(csvRow(listOf("Status", personWithPayments.status.label)))
        sb.appendLine(csvRow(listOf("Due Date", person.dueDateMillis?.let { DateUtils.formatDate(it) } ?: "Not set")))
        sb.appendLine()
        sb.appendLine(csvRow(listOf("Date", "Amount", "Method", "Reference", "Notes")))
        personWithPayments.payments.sortedBy { it.paymentDateMillis }.forEach { pay ->
            sb.appendLine(
                csvRow(
                    listOf(
                        DateUtils.formatDate(pay.paymentDateMillis),
                        IndianCurrencyFormatter.formatPaise(pay.amountPaise, currencySymbol),
                        pay.paymentMethod.displayName,
                        pay.transactionReference.orEmpty(),
                        pay.notes.orEmpty()
                    )
                )
            )
        }
        return sb.toString()
    }

    fun generateFullReportPdf(
        context: Context,
        people: List<PersonWithPayments>,
        payments: List<PaymentWithPerson>,
        currencySymbol: String = "₹"
    ): File {
        val file = createExportFile(context, "Hisab_Collection_Report_${DateUtils.formatFileTimestamp()}.pdf")
        writePdf(file) { writer ->
            writer.drawTitle(APP_TITLE, "Collection & Outstanding Report")
            writer.drawSubText("Generated: ${DateUtils.formatDateTime(System.currentTimeMillis())}")
            writer.addSpace(10f)

            val totalOwed = people.sumOf { it.person.totalAmountPaise }
            val totalPaid = people.sumOf { it.totalPaidPaise }
            val totalPending = people.sumOf { it.remainingBalancePaise }

            writer.drawSectionHeader("Summary")
            writer.drawKeyValue("Total to Collect", IndianCurrencyFormatter.formatPaise(totalOwed, currencySymbol))
            writer.drawKeyValue("Total Collected", IndianCurrencyFormatter.formatPaise(totalPaid, currencySymbol))
            writer.drawKeyValue("Total Outstanding", IndianCurrencyFormatter.formatPaise(totalPending, currencySymbol))
            writer.drawKeyValue("People Tracked", "${people.size} (${people.count { it.remainingBalancePaise > 0 }} pending)")
            writer.addSpace(12f)

            writer.drawSectionHeader("Person-wise Balances")
            people.forEach { p ->
                val line = "${p.person.name} (${PhoneNumberHelper.formatForDisplay(p.person.phoneNumber)})"
                val detail = "Total: ${IndianCurrencyFormatter.formatPaise(p.person.totalAmountPaise, currencySymbol)} | " +
                    "Paid: ${IndianCurrencyFormatter.formatPaise(p.totalPaidPaise, currencySymbol)} | " +
                    "Remaining: ${IndianCurrencyFormatter.formatPaise(p.remainingBalancePaise, currencySymbol)} [${p.status.label}]"
                writer.drawBodyLine(line, bold = true)
                writer.drawBodyLine(detail, bold = false)
                writer.addSpace(4f)
            }

            if (payments.isNotEmpty()) {
                writer.addSpace(10f)
                writer.drawSectionHeader("Recent Payment Transactions")
                payments.forEach { item ->
                    val ref = item.payment.transactionReference?.let { " | Ref: $it" }.orEmpty()
                    val line = "${DateUtils.formatDate(item.payment.paymentDateMillis)} — ${item.person.name}: " +
                        "${IndianCurrencyFormatter.formatPaise(item.payment.amountPaise, currencySymbol)} (${item.payment.paymentMethod.displayName}$ref)"
                    writer.drawBodyLine(line, bold = false)
                }
            }
        }
        return file
    }

    fun generatePersonStatementPdf(
        context: Context,
        personWithPayments: PersonWithPayments,
        currencySymbol: String = "₹"
    ): File {
        val safeName = personWithPayments.person.name.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val file = createExportFile(context, "Hisab_Statement_${safeName}_${DateUtils.formatFileTimestamp()}.pdf")
        val person = personWithPayments.person

        writePdf(file) { writer ->
            writer.drawTitle(APP_TITLE, "Individual Payment Statement")
            writer.drawSubText("Generated: ${DateUtils.formatDateTime(System.currentTimeMillis())}")
            writer.addSpace(10f)

            writer.drawSectionHeader("Person Details")
            writer.drawKeyValue("Name", person.name)
            writer.drawKeyValue("Phone", PhoneNumberHelper.formatForDisplay(person.phoneNumber))
            writer.drawKeyValue("Original Amount", IndianCurrencyFormatter.formatPaise(person.totalAmountPaise, currencySymbol))
            writer.drawKeyValue("Total Paid", IndianCurrencyFormatter.formatPaise(personWithPayments.totalPaidPaise, currencySymbol))
            writer.drawKeyValue("Remaining Balance", IndianCurrencyFormatter.formatPaise(personWithPayments.remainingBalancePaise, currencySymbol))
            writer.drawKeyValue("Status", personWithPayments.status.label)
            person.dueDateMillis?.let { writer.drawKeyValue("Due Date", DateUtils.formatDate(it)) }
            person.notes?.let { writer.drawKeyValue("Notes", it) }

            writer.addSpace(12f)
            writer.drawSectionHeader("Payment History (${personWithPayments.payments.size})")
            if (personWithPayments.payments.isEmpty()) {
                writer.drawBodyLine("No payments recorded yet.", bold = false)
            } else {
                personWithPayments.payments.sortedBy { it.paymentDateMillis }.forEach { pay ->
                    val ref = pay.transactionReference?.let { " | Ref: $it" }.orEmpty()
                    val note = pay.notes?.let { " | $it" }.orEmpty()
                    val line = "${DateUtils.formatDate(pay.paymentDateMillis)} — " +
                        "${IndianCurrencyFormatter.formatPaise(pay.amountPaise, currencySymbol)} " +
                        "(${pay.paymentMethod.displayName}$ref)$note"
                    writer.drawBodyLine(line, bold = false)
                }
            }
        }
        return file
    }

    fun writeCsvToCache(context: Context, filename: String, content: String): File {
        val file = createExportFile(context, filename)
        file.writeText(content, Charsets.UTF_8)
        return file
    }

    fun shareFile(context: Context, file: File, mimeType: String, title: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(Intent.createChooser(intent, title).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    private fun createExportFile(context: Context, filename: String): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        return File(dir, filename)
    }

    private fun csvRow(cells: List<String>): String =
        cells.joinToString(",") { cell ->
            val escaped = cell.replace("\"", "\"\"")
            "\"$escaped\""
        }

    private fun writePdf(file: File, block: (PdfWriter) -> Unit) {
        val document = PdfDocument()
        val writer = PdfWriter(document)
        writer.startNewPage()
        block(writer)
        writer.finishCurrentPage()
        FileOutputStream(file).use { out -> document.writeTo(out) }
        document.close()
    }

    private class PdfWriter(private val document: PdfDocument) {
        private val pageWidth = 595 // A4 points
        private val pageHeight = 842
        private val margin = 40f
        private var pageNumber = 0
        private var currentPage: PdfDocument.Page? = null
        private var canvas: Canvas? = null
        private var y = margin

        private val titlePaint = Paint().apply {
            color = Color.parseColor("#0F766E")
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        private val subtitlePaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        private val sectionPaint = Paint().apply {
            color = Color.BLACK
            textSize = 13f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        private val bodyPaint = Paint().apply {
            color = Color.BLACK
            textSize = 10.5f
            isAntiAlias = true
        }
        private val bodyBoldPaint = Paint().apply {
            color = Color.BLACK
            textSize = 10.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        private val mutedPaint = Paint().apply {
            color = Color.GRAY
            textSize = 9.5f
            isAntiAlias = true
        }

        fun startNewPage() {
            finishCurrentPage()
            pageNumber++
            val info = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
            currentPage = document.startPage(info)
            canvas = currentPage?.canvas
            y = margin
        }

        fun finishCurrentPage() {
            currentPage?.let { document.finishPage(it) }
            currentPage = null
            canvas = null
        }

        private fun ensureSpace(heightNeeded: Float) {
            if (y + heightNeeded > pageHeight - margin) {
                startNewPage()
            }
        }

        fun addSpace(dp: Float) {
            y += dp
        }

        fun drawTitle(appTitle: String, subtitle: String) {
            ensureSpace(44f)
            canvas?.drawText(appTitle, margin, y, titlePaint)
            y += 20f
            canvas?.drawText(subtitle, margin, y, subtitlePaint)
            y += 16f
        }

        fun drawSubText(text: String) {
            ensureSpace(16f)
            canvas?.drawText(text, margin, y, mutedPaint)
            y += 14f
        }

        fun drawSectionHeader(title: String) {
            ensureSpace(24f)
            canvas?.drawText(title, margin, y, sectionPaint)
            y += 6f
            canvas?.drawLine(margin, y, pageWidth - margin, y, mutedPaint)
            y += 14f
        }

        fun drawKeyValue(key: String, value: String) {
            ensureSpace(16f)
            canvas?.drawText("$key: $value", margin, y, bodyPaint)
            y += 15f
        }

        fun drawBodyLine(text: String, bold: Boolean) {
            val paint = if (bold) bodyBoldPaint else bodyPaint
            val maxWidth = pageWidth - 2 * margin
            val words = text.split(" ")
            var line = ""
            for (word in words) {
                val candidate = if (line.isEmpty()) word else "$line $word"
                if (paint.measureText(candidate) > maxWidth && line.isNotEmpty()) {
                    ensureSpace(15f)
                    canvas?.drawText(line, margin, y, paint)
                    y += 14f
                    line = word
                } else {
                    line = candidate
                }
            }
            if (line.isNotEmpty()) {
                ensureSpace(15f)
                canvas?.drawText(line, margin, y, paint)
                y += 14f
            }
        }
    }
}

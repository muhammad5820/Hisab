package com.hisab.app.data.preferences

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.security.MessageDigest

enum class ThemeMode(val label: String) {
    SYSTEM("System Default"),
    LIGHT("Light"),
    DARK("Dark")
}

enum class CurrencyDisplayMode(val symbol: String, val label: String) {
    RUPEE_SYMBOL("₹", "₹ (Indian Rupee)"),
    INR_PREFIX("INR ", "INR (Text)")
}

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val currencyDisplay: CurrencyDisplayMode = CurrencyDisplayMode.RUPEE_SYMBOL,
    val notificationsEnabled: Boolean = true,
    val reminderHour: Int = 9,
    val reminderMinute: Int = 0,
    val appLockEnabled: Boolean = false,
    val biometricEnabled: Boolean = false,
    val hasPinSet: Boolean = false
)

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("hisab_prefs", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(readSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun readSettings(): AppSettings {
        val themeStr = prefs.getString(KEY_THEME, ThemeMode.SYSTEM.name) ?: ThemeMode.SYSTEM.name
        val currencyStr = prefs.getString(KEY_CURRENCY, CurrencyDisplayMode.RUPEE_SYMBOL.name)
            ?: CurrencyDisplayMode.RUPEE_SYMBOL.name
        val pinHash = prefs.getString(KEY_PIN_HASH, null)

        return AppSettings(
            themeMode = runCatching { ThemeMode.valueOf(themeStr) }.getOrDefault(ThemeMode.SYSTEM),
            currencyDisplay = runCatching { CurrencyDisplayMode.valueOf(currencyStr) }
                .getOrDefault(CurrencyDisplayMode.RUPEE_SYMBOL),
            notificationsEnabled = prefs.getBoolean(KEY_NOTIFICATIONS, true),
            reminderHour = prefs.getInt(KEY_REMINDER_HOUR, 9),
            reminderMinute = prefs.getInt(KEY_REMINDER_MINUTE, 0),
            appLockEnabled = prefs.getBoolean(KEY_APP_LOCK, false) && !pinHash.isNullOrBlank(),
            biometricEnabled = prefs.getBoolean(KEY_BIOMETRIC, false),
            hasPinSet = !pinHash.isNullOrBlank()
        )
    }

    fun setThemeMode(mode: ThemeMode) {
        prefs.edit().putString(KEY_THEME, mode.name).apply()
        _settings.value = readSettings()
    }

    fun setCurrencyDisplay(mode: CurrencyDisplayMode) {
        prefs.edit().putString(KEY_CURRENCY, mode.name).apply()
        _settings.value = readSettings()
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_NOTIFICATIONS, enabled).apply()
        _settings.value = readSettings()
    }

    fun setReminderTime(hour: Int, minute: Int) {
        prefs.edit()
            .putInt(KEY_REMINDER_HOUR, hour.coerceIn(0, 23))
            .putInt(KEY_REMINDER_MINUTE, minute.coerceIn(0, 59))
            .apply()
        _settings.value = readSettings()
    }

    fun setPinAndEnableLock(pin: String) {
        val hash = sha256(pin)
        prefs.edit()
            .putString(KEY_PIN_HASH, hash)
            .putBoolean(KEY_APP_LOCK, true)
            .apply()
        _settings.value = readSettings()
    }

    fun verifyPin(pin: String): Boolean {
        val stored = prefs.getString(KEY_PIN_HASH, null) ?: return false
        return stored == sha256(pin)
    }

    fun disableAppLock() {
        prefs.edit()
            .putBoolean(KEY_APP_LOCK, false)
            .putBoolean(KEY_BIOMETRIC, false)
            .remove(KEY_PIN_HASH)
            .apply()
        _settings.value = readSettings()
    }

    fun setBiometricEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_BIOMETRIC, enabled).apply()
        _settings.value = readSettings()
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(("hisab_salt_$input").toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    companion object {
        private const val KEY_THEME = "theme_mode"
        private const val KEY_CURRENCY = "currency_display"
        private const val KEY_NOTIFICATIONS = "notifications_enabled"
        private const val KEY_REMINDER_HOUR = "reminder_hour"
        private const val KEY_REMINDER_MINUTE = "reminder_minute"
        private const val KEY_APP_LOCK = "app_lock_enabled"
        private const val KEY_BIOMETRIC = "biometric_enabled"
        private const val KEY_PIN_HASH = "pin_hash"
    }
}

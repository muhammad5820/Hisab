package com.hisab.app

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.hisab.app.data.local.entity.PaymentEntity
import com.hisab.app.ui.components.RecordOrEditPaymentSheet
import com.hisab.app.ui.screens.AddEditPersonScreen
import com.hisab.app.ui.screens.AppLockScreen
import com.hisab.app.ui.screens.DashboardScreen
import com.hisab.app.ui.screens.HistoryScreen
import com.hisab.app.ui.screens.PeopleScreen
import com.hisab.app.ui.screens.PersonDetailScreen
import com.hisab.app.ui.screens.ReportsScreen
import com.hisab.app.ui.screens.SettingsScreen
import com.hisab.app.ui.theme.HisabTheme
import com.hisab.app.ui.viewmodel.HisabViewModel
import com.hisab.app.worker.PaymentReminderWorker

private sealed class BottomTab(val route: String, val label: String, val icon: ImageVector) {
    data object Home : BottomTab("home", "Home", Icons.Default.Home)
    data object People : BottomTab("people", "People", Icons.Default.People)
    data object History : BottomTab("history", "History", Icons.Default.History)
    data object Reports : BottomTab("reports", "Reports", Icons.Default.Assessment)
    data object Settings : BottomTab("settings", "Settings", Icons.Default.Settings)
}

class MainActivity : FragmentActivity() {

    private val viewModel: HisabViewModel by viewModels {
        val app = application as HisabApplication
        HisabViewModel.Factory(app.repository, app.preferences)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val initialPersonId = intent?.getLongExtra(PaymentReminderWorker.EXTRA_PERSON_ID, -1L)
            ?.takeIf { it > 0L }

        setContent {
            val settings by viewModel.appSettings.collectAsStateWithLifecycle()
            var unlocked by rememberSaveable { mutableStateOf(!settings.appLockEnabled) }

            LaunchedEffect(settings.appLockEnabled) {
                if (!settings.appLockEnabled) unlocked = true
            }

            HisabTheme(themeMode = settings.themeMode) {
                if (settings.appLockEnabled && !unlocked) {
                    AppLockScreen(
                        biometricEnabled = settings.biometricEnabled,
                        onVerifyPin = { viewModel.verifyPin(it) },
                        onUnlocked = { unlocked = true }
                    )
                } else {
                    HisabMainApp(viewModel = viewModel, initialPersonId = initialPersonId)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HisabMainApp(
    viewModel: HisabViewModel,
    initialPersonId: Long?
) {
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }

    val summary by viewModel.dashboardSummary.collectAsStateWithLifecycle()
    val people by viewModel.allPeople.collectAsStateWithLifecycle()
    val payments by viewModel.allPayments.collectAsStateWithLifecycle()
    val settings by viewModel.appSettings.collectAsStateWithLifecycle()
    val currencySymbol = settings.currencyDisplay.symbol

    var showPaymentSheetForPersonId by remember { mutableStateOf<Long?>(null) }
    var showPaymentSheetOpen by remember { mutableStateOf(false) }
    var editingPayment by remember { mutableStateOf<PaymentEntity?>(null) }

    LaunchedEffect(Unit) {
        viewModel.uiMessages.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    LaunchedEffect(initialPersonId) {
        if (initialPersonId != null) {
            navController.navigate("person/$initialPersonId")
        }
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val tabs = listOf(
        BottomTab.Home,
        BottomTab.People,
        BottomTab.History,
        BottomTab.Reports,
        BottomTab.Settings
    )
    val showBottomBar = currentRoute in tabs.map { it.route }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            if (showBottomBar) {
                val title = when (currentRoute) {
                    BottomTab.Home.route -> "Hisab"
                    BottomTab.People.route -> "People"
                    BottomTab.History.route -> "Payment History"
                    BottomTab.Reports.route -> "Reports & Exports"
                    BottomTab.Settings.route -> "Settings"
                    else -> "Hisab"
                }
                TopAppBar(title = { Text(title) })
            }
        },
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    tabs.forEach { tab ->
                        NavigationBarItem(
                            selected = currentRoute == tab.route,
                            onClick = {
                                navController.navigate(tab.route) {
                                    popUpTo(BottomTab.Home.route) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            if (currentRoute == BottomTab.Home.route || currentRoute == BottomTab.People.route) {
                FloatingActionButton(
                    onClick = { navController.navigate("add_person") }
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Person")
                }
            } else if (currentRoute == BottomTab.History.route && people.any { it.remainingBalancePaise > 0L }) {
                FloatingActionButton(
                    onClick = {
                        showPaymentSheetForPersonId = null
                        editingPayment = null
                        showPaymentSheetOpen = true
                    }
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Record Payment")
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = BottomTab.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(BottomTab.Home.route) {
                DashboardScreen(
                    summary = summary,
                    people = people,
                    recentPayments = payments,
                    currencySymbol = currencySymbol,
                    onPersonClick = { id -> navController.navigate("person/$id") },
                    onQuickAddPerson = { navController.navigate("add_person") },
                    onQuickRecordPayment = {
                        showPaymentSheetForPersonId = null
                        editingPayment = null
                        showPaymentSheetOpen = true
                    },
                    onPostMessage = { viewModel.postMessage(it) }
                )
            }

            composable(BottomTab.People.route) {
                PeopleScreen(
                    people = people,
                    currencySymbol = currencySymbol,
                    onPersonClick = { id -> navController.navigate("person/$id") }
                )
            }

            composable(BottomTab.History.route) {
                HistoryScreen(
                    payments = payments,
                    people = people,
                    currencySymbol = currencySymbol,
                    onEditPayment = { pay ->
                        editingPayment = pay
                        showPaymentSheetForPersonId = pay.personId
                        showPaymentSheetOpen = true
                    },
                    onDeletePayment = { pay -> viewModel.deletePayment(pay) }
                )
            }

            composable(BottomTab.Reports.route) {
                ReportsScreen(
                    summary = summary,
                    people = people,
                    payments = payments,
                    currencySymbol = currencySymbol,
                    onPostMessage = { viewModel.postMessage(it) }
                )
            }

            composable(BottomTab.Settings.route) {
                SettingsScreen(
                    settings = settings,
                    people = people,
                    payments = payments,
                    onThemeChange = { viewModel.setThemeMode(it) },
                    onCurrencyChange = { viewModel.setCurrencyDisplay(it) },
                    onNotificationsChange = { viewModel.setNotificationsEnabled(it) },
                    onExportBackupJson = { viewModel.exportBackupJson() },
                    onRestoreBackupJson = { viewModel.restoreBackupJson(it) },
                    onSetPin = { viewModel.setPinAndEnableLock(it) },
                    onDisableLock = { viewModel.disableAppLock() },
                    onBiometricChange = { viewModel.setBiometricEnabled(it) },
                    onClearAllData = { viewModel.clearAllData() },
                    onPostMessage = { viewModel.postMessage(it) }
                )
            }

            composable("add_person") {
                AddEditPersonScreen(
                    existingPerson = null,
                    currencySymbol = currencySymbol,
                    checkDuplicatePhone = { phone, excludeId ->
                        viewModel.checkDuplicatePhone(phone, excludeId)
                    },
                    onSave = { name, phone, totalPaise, created, due, notes ->
                        viewModel.savePerson(
                            personId = null,
                            name = name,
                            phoneNumber = phone,
                            totalAmountPaise = totalPaise,
                            createdDateMillis = created,
                            dueDateMillis = due,
                            notes = notes
                        ) { newId ->
                            navController.popBackStack()
                            navController.navigate("person/$newId")
                        }
                    },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(
                route = "edit_person/{personId}",
                arguments = listOf(navArgument("personId") { type = NavType.LongType })
            ) { backStack ->
                val personId = backStack.arguments?.getLong("personId") ?: return@composable
                val personRecord by viewModel.observePerson(personId).collectAsStateWithLifecycle(initialValue = null)
                AddEditPersonScreen(
                    existingPerson = personRecord?.person,
                    totalAlreadyPaidPaise = personRecord?.totalPaidPaise ?: 0L,
                    currencySymbol = currencySymbol,
                    checkDuplicatePhone = { phone, excludeId ->
                        viewModel.checkDuplicatePhone(phone, excludeId)
                    },
                    onSave = { name, phone, totalPaise, created, due, notes ->
                        viewModel.savePerson(
                            personId = personId,
                            name = name,
                            phoneNumber = phone,
                            totalAmountPaise = totalPaise,
                            createdDateMillis = created,
                            dueDateMillis = due,
                            notes = notes
                        ) {
                            navController.popBackStack()
                        }
                    },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(
                route = "person/{personId}",
                arguments = listOf(navArgument("personId") { type = NavType.LongType })
            ) { backStack ->
                val personId = backStack.arguments?.getLong("personId") ?: return@composable
                val personRecord by viewModel.observePerson(personId).collectAsStateWithLifecycle(initialValue = null)

                PersonDetailScreen(
                    personWithPayments = personRecord,
                    currencySymbol = currencySymbol,
                    onBack = { navController.popBackStack() },
                    onEditPerson = { id -> navController.navigate("edit_person/$id") },
                    onDeletePerson = { p ->
                        viewModel.deletePerson(p.person) {
                            navController.popBackStack()
                        }
                    },
                    onRecordPayment = { id ->
                        editingPayment = null
                        showPaymentSheetForPersonId = id
                        showPaymentSheetOpen = true
                    },
                    onEditPayment = { pay ->
                        editingPayment = pay
                        showPaymentSheetForPersonId = pay.personId
                        showPaymentSheetOpen = true
                    },
                    onDeletePayment = { pay -> viewModel.deletePayment(pay) },
                    onPostMessage = { viewModel.postMessage(it) }
                )
            }
        }
    }

    if (showPaymentSheetOpen) {
        RecordOrEditPaymentSheet(
            people = people,
            initialPersonId = showPaymentSheetForPersonId,
            editingPayment = editingPayment,
            currencySymbol = currencySymbol,
            onDismiss = {
                showPaymentSheetOpen = false
                editingPayment = null
            },
            onSubmit = { pid, amountPaise, dateMillis, method, ref, notes ->
                val currentEdit = editingPayment
                if (currentEdit == null) {
                    viewModel.recordPayment(pid, amountPaise, dateMillis, method, ref, notes) {
                        showPaymentSheetOpen = false
                    }
                } else {
                    viewModel.updatePayment(currentEdit.id, amountPaise, dateMillis, method, ref, notes) {
                        showPaymentSheetOpen = false
                        editingPayment = null
                    }
                }
            }
        )
    }
}

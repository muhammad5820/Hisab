package com.hisab.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.hisab.app.BuildConfig
import com.hisab.app.data.local.entity.PaymentWithPerson
import com.hisab.app.data.local.entity.PersonWithPayments
import com.hisab.app.data.preferences.AppSettings
import com.hisab.app.data.preferences.CurrencyDisplayMode
import com.hisab.app.data.preferences.ThemeMode
import com.hisab.app.ui.components.ConfirmActionDialog
import com.hisab.app.ui.theme.OverdueRed
import com.hisab.app.util.DateUtils
import com.hisab.app.util.ExportHelper
import com.hisab.app.worker.ReminderScheduler
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    settings: AppSettings,
    people: List<PersonWithPayments>,
    payments: List<PaymentWithPerson>,
    onThemeChange: (ThemeMode) -> Unit,
    onCurrencyChange: (CurrencyDisplayMode) -> Unit,
    onNotificationsChange: (Boolean) -> Unit,
    onExportBackupJson: suspend () -> String,
    onRestoreBackupJson: (String) -> Unit,
    onSetPin: (String) -> Unit,
    onDisableLock: () -> Unit,
    onBiometricChange: (Boolean) -> Unit,
    onClearAllData: () -> Unit,
    onPostMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var showPinDialog by remember { mutableStateOf(false) }
    var showClearConfirm1 by remember { mutableStateOf(false) }
    var showClearConfirm2 by remember { mutableStateOf(false) }
    var pendingRestoreJson by remember { mutableStateOf<String?>(null) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            onNotificationsChange(true)
            ReminderScheduler.scheduleDailyCheck(context)
            onPostMessage("Payment reminder notifications enabled")
        } else {
            onNotificationsChange(false)
            onPostMessage("Notification permission denied")
        }
    }

    val backupCreateLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val json = onExportBackupJson()
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(json.toByteArray(Charsets.UTF_8))
                }
                onPostMessage("Backup saved successfully")
            }
        }
    }

    val backupRestoreLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val content = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            if (content != null) {
                pendingRestoreJson = content
            } else {
                onPostMessage("Unable to read selected backup file")
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Appearance
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Appearance", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemeMode.entries.forEach { mode ->
                            FilterChip(
                                selected = settings.themeMode == mode,
                                onClick = { onThemeChange(mode) },
                                label = { Text(mode.label) }
                            )
                        }
                    }

                    Text("Currency Display", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CurrencyDisplayMode.entries.forEach { mode ->
                            FilterChip(
                                selected = settings.currencyDisplay == mode,
                                onClick = { onCurrencyChange(mode) },
                                label = { Text(mode.label) }
                            )
                        }
                    }
                }
            }
        }

        // Notifications
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Local Payment Reminders", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Daily check for overdue and upcoming due dates",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = settings.notificationsEnabled,
                            onCheckedChange = { enabled ->
                                if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    val granted = ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.POST_NOTIFICATIONS
                                    ) == PackageManager.PERMISSION_GRANTED
                                    if (!granted) {
                                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                        return@Switch
                                    }
                                }
                                onNotificationsChange(enabled)
                            }
                        )
                    }
                    OutlinedButton(
                        onClick = {
                            ReminderScheduler.triggerImmediateCheck(context)
                            onPostMessage("Checked due dates for reminder notifications")
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Run Reminder Check Now") }
                }
            }
        }

        // Security / App Lock
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("App Lock (4-Digit PIN)", style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (settings.appLockEnabled) "Enabled" else "Off",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = settings.appLockEnabled,
                            onCheckedChange = { enabled ->
                                if (enabled) showPinDialog = true else onDisableLock()
                            }
                        )
                    }

                    if (settings.appLockEnabled) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Unlock with Biometrics", style = MaterialTheme.typography.bodyLarge)
                            Switch(
                                checked = settings.biometricEnabled,
                                onCheckedChange = onBiometricChange
                            )
                        }
                    }
                }
            }
        }

        // Backup, Restore & Export
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Backup & Data", style = MaterialTheme.typography.titleMedium)
                    Button(
                        onClick = {
                            backupCreateLauncher.launch("Hisab_Backup_${DateUtils.formatFileTimestamp()}.json")
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) { Text("Backup Database (Local JSON)") }

                    OutlinedButton(
                        onClick = {
                            backupRestoreLauncher.launch(arrayOf("application/json", "*/*"))
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) { Text("Restore Database from File") }

                    OutlinedButton(
                        onClick = {
                            val csv = ExportHelper.generateFullReportCsv(
                                people, payments, settings.currencyDisplay.symbol
                            )
                            val file = ExportHelper.writeCsvToCache(
                                context,
                                "Hisab_All_Data_${DateUtils.formatFileTimestamp()}.csv",
                                csv
                            )
                            ExportHelper.shareFile(context, file, "text/csv", "Hisab All Data Export")
                        },
                        enabled = people.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) { Text("Export All Data (CSV)") }

                    Button(
                        onClick = { showClearConfirm1 = true },
                        colors = ButtonDefaults.buttonColors(containerColor = OverdueRed, contentColor = Color.White),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) { Text("Clear All Data") }
                }
            }
        }

        // About
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Hisab – Personal Money Collection Manager", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Version ${BuildConfig.VERSION_NAME} • 100% Offline Local Storage",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        "All records stay strictly on your device. No cloud servers or banking APIs.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item { Spacer(Modifier.height(72.dp)) }
    }

    if (showPinDialog) {
        var pinInput by remember { mutableStateOf("") }
        var pinError by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            title = { Text("Set 4-Digit App PIN") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = {
                            if (it.length <= 4 && it.all { c -> c.isDigit() }) {
                                pinInput = it
                                pinError = null
                            }
                        },
                        label = { Text("4-Digit PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true
                    )
                    if (pinError != null) {
                        Text(pinError!!, color = OverdueRed, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (pinInput.length != 4) {
                        pinError = "PIN must be exactly 4 digits."
                    } else {
                        onSetPin(pinInput)
                        showPinDialog = false
                    }
                }) { Text("Enable Lock") }
            },
            dismissButton = {
                TextButton(onClick = { showPinDialog = false }) { Text("Cancel") }
            }
        )
    }

    pendingRestoreJson?.let { json ->
        ConfirmActionDialog(
            title = "Restore Backup?",
            message = "Restoring will replace all current records in Hisab with the data from the selected backup file.",
            confirmLabel = "Restore",
            isDestructive = true,
            onDismiss = { pendingRestoreJson = null },
            onConfirm = {
                onRestoreBackupJson(json)
                pendingRestoreJson = null
            }
        )
    }

    if (showClearConfirm1) {
        ConfirmActionDialog(
            title = "Clear All Data?",
            message = "This will permanently delete all people and payment transactions on this device.",
            confirmLabel = "Continue",
            isDestructive = true,
            onDismiss = { showClearConfirm1 = false },
            onConfirm = {
                showClearConfirm1 = false
                showClearConfirm2 = true
            }
        )
    }

    if (showClearConfirm2) {
        ConfirmActionDialog(
            title = "Final Confirmation",
            message = "Are you absolutely sure? This action cannot be undone unless you have a local backup.",
            confirmLabel = "Delete Everything",
            isDestructive = true,
            onDismiss = { showClearConfirm2 = false },
            onConfirm = {
                showClearConfirm2 = false
                onClearAllData()
            }
        )
    }
}

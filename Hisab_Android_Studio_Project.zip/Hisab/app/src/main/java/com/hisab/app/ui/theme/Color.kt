package com.hisab.app.ui.theme

import androidx.compose.ui.graphics.Color

val TealPrimary = Color(0xFF0F766E)
val TealOnPrimary = Color(0xFFFFFFFF)
val TealPrimaryContainer = Color(0xFFCCFBF1)
val TealOnPrimaryContainer = Color(0xFF042F2E)

val TealSecondary = Color(0xFF0284C7)
val TealSecondaryContainer = Color(0xFFE0F2FE)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOutline = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)

val DarkPrimary = Color(0xFF2DD4BF)
val DarkOnPrimary = Color(0xFF042F2E)
val DarkPrimaryContainer = Color(0xFF115E59)
val DarkOnPrimaryContainer = Color(0xFFCCFBF1)

val DarkBackground = Color(0xFF0B1120)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkOutline = Color(0xFF334155)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)

// Semantic finance colors
val CollectedGreen = Color(0xFF16A34A)
val CollectedGreenBgLight = Color(0xFFDCFCE7)
val CollectedGreenBgDark = Color(0xFF14532D)

val PendingOrange = Color(0xFFEA580C)
val PendingOrangeBgLight = Color(0xFFFFEDD5)
val PendingOrangeBgDark = Color(0xFF7C2D12)

val OverdueRed = Color(0xFFDC2626)
val OverdueRedBgLight = Color(0xFFFEE2E2)
val OverdueRedBgDark = Color(0xFF7F1D1D)

val WhatsAppGreen = Color(0xFF25D366)

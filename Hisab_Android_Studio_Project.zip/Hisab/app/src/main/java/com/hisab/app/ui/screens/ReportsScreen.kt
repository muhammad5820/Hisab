package com.hisab.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hisab.app.data.local.entity.PaymentWithPerson
import com.hisab.app.data.local.entity.PersonWithPayments
import com.hisab.app.data.repository.DashboardSummary
import com.hisab.app.ui.theme.CollectedGreen
import com.hisab.app.ui.theme.PendingOrange
import com.hisab.app.ui.viewmodel.HistoryDateFilter
import com.hisab.app.util.DateUtils
import com.hisab.app.util.ExportHelper
import com.hisab.app.util.IndianCurrencyFormatter

@Composable
fun ReportsScreen(
    summary: DashboardSummary,
    people: List<PersonWithPayments>,
    payments: List<PaymentWithPerson>,
    currencySymbol: String,
    onPostMessage: (String) -> Unit
) {
    val context = LocalContext.current
    var periodFilter by remember { mutableStateOf(HistoryDateFilter.THIS_MONTH) }
    var selectedPersonForStatement by remember { mutableStateOf<PersonWithPayments?>(people.firstOrNull()) }
    var showPersonDropdown by remember { mutableStateOf(false) }

    val periodPayments = remember(payments, periodFilter) {
        val now = System.currentTimeMillis()
        val threshold = when (periodFilter) {
            HistoryDateFilter.ALL, HistoryDateFilter.CUSTOM -> Long.MIN_VALUE
            HistoryDateFilter.TODAY -> DateUtils.startOfTodayMillis(now)
            HistoryDateFilter.THIS_WEEK -> DateUtils.startOfWeekMillis(now)
            HistoryDateFilter.THIS_MONTH -> DateUtils.startOfMonthMillis(now)
        }
        payments.filter { it.payment.paymentDateMillis >= threshold }
    }
    val periodReceivedPaise = remember(periodPayments) { periodPayments.sumOf { it.payment.amountPaise } }

    val monthlySummary = remember(payments) {
        payments
            .groupBy { DateUtils.formatMonthYear(it.payment.paymentDateMillis) }
            .map { (month, list) -> month to list.sumOf { it.payment.amountPaise } }
    }

    val pendingPeople = remember(people) {
        people.filter { it.remainingBalancePaise > 0L }
            .sortedByDescending { it.remainingBalancePaise }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Overview Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Collection Overview", style = MaterialTheme.typography.titleMedium)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Total Collection", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                IndianCurrencyFormatter.formatPaise(summary.totalCollectedPaise, currencySymbol),
                                style = MaterialTheme.typography.titleLarge,
                                color = CollectedGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Total Outstanding", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                IndianCurrencyFormatter.formatPaise(summary.totalOutstandingPaise, currencySymbol),
                                style = MaterialTheme.typography.titleLarge,
                                color = PendingOrange,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Period Collection Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Received During Period", style = MaterialTheme.typography.titleMedium)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            HistoryDateFilter.TODAY,
                            HistoryDateFilter.THIS_WEEK,
                            HistoryDateFilter.THIS_MONTH,
                            HistoryDateFilter.ALL
                        ).forEach { f ->
                            FilterChip(
                                selected = periodFilter == f,
                                onClick = { periodFilter = f },
                                label = { Text(f.label) }
                            )
                        }
                    }
                    Text(
                        text = IndianCurrencyFormatter.formatPaise(periodReceivedPaise, currencySymbol),
                        style = MaterialTheme.typography.headlineMedium,
                        color = CollectedGreen
                    )
                    Text(
                        text = "${periodPayments.size} payment(s) in ${periodFilter.label.lowercase()}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Export Full Reports
        item {
            Text("Export Full Report", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = {
                        val csv = ExportHelper.generateFullReportCsv(people, payments, currencySymbol)
                        val file = ExportHelper.writeCsvToCache(
                            context,
                            "Hisab_Collection_Report_${DateUtils.formatFileTimestamp()}.csv",
                            csv
                        )
                        ExportHelper.shareFile(context, file, "text/csv", "Hisab Collection Report (CSV)")
                    },
                    enabled = people.isNotEmpty(),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Export CSV")
                }
                OutlinedButton(
                    onClick = {
                        val file = ExportHelper.generateFullReportPdf(context, people, payments, currencySymbol)
                        ExportHelper.shareFile(context, file, "application/pdf", "Hisab Collection Report (PDF)")
                    },
                    enabled = people.isNotEmpty(),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Export PDF")
                }
            }
        }

        // Individual Statement Export
        if (people.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Individual Payment Statement", style = MaterialTheme.typography.titleMedium)
                        Box {
                            OutlinedButton(
                                onClick = { showPersonDropdown = true },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(selectedPersonForStatement?.person?.name ?: people.first().person.name)
                            }
                            DropdownMenu(
                                expanded = showPersonDropdown,
                                onDismissRequest = { showPersonDropdown = false }
                            ) {
                                people.forEach { p ->
                                    DropdownMenuItem(
                                        text = { Text(p.person.name) },
                                        onClick = {
                                            selectedPersonForStatement = p
                                            showPersonDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                        val target = selectedPersonForStatement ?: people.first()
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(
                                onClick = {
                                    val csv = ExportHelper.generatePersonStatementCsv(target, currencySymbol)
                                    val safeName = target.person.name.replace(Regex("[^A-Za-z0-9_-]"), "_")
                                    val file = ExportHelper.writeCsvToCache(
                                        context,
                                        "Hisab_Statement_${safeName}_${DateUtils.formatFileTimestamp()}.csv",
                                        csv
                                    )
                                    ExportHelper.shareFile(context, file, "text/csv", "${target.person.name} Statement (CSV)")
                                },
                                modifier = Modifier.weight(1f)
                            ) { Text("Statement CSV") }
                            OutlinedButton(
                                onClick = {
                                    val file = ExportHelper.generatePersonStatementPdf(context, target, currencySymbol)
                                    ExportHelper.shareFile(context, file, "application/pdf", "${target.person.name} Statement (PDF)")
                                },
                                modifier = Modifier.weight(1f)
                            ) { Text("Statement PDF") }
                        }
                    }
                }
            }
        }

        // Monthly Collection Summary
        if (monthlySummary.isNotEmpty()) {
            item {
                Text("Monthly Collection Summary", style = MaterialTheme.typography.titleMedium)
            }
            items(monthlySummary) { (month, totalPaise) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(month, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        IndianCurrencyFormatter.formatPaise(totalPaise, currencySymbol),
                        style = MaterialTheme.typography.bodyLarge,
                        color = CollectedGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Person-wise Pending Balances
        if (pendingPeople.isNotEmpty()) {
            item {
                Text("Person-wise Pending Balances", style = MaterialTheme.typography.titleMedium)
            }
            items(pendingPeople, key = { "rep_${it.person.id}" }) { p ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(p.person.name, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        IndianCurrencyFormatter.formatPaise(p.remainingBalancePaise, currencySymbol),
                        style = MaterialTheme.typography.bodyLarge,
                        color = PendingOrange,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        item { Spacer(Modifier.height(72.dp)) }
    }
}

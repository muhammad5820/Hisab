package com.hisab.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hisab.app.data.local.entity.PaymentWithPerson
import com.hisab.app.data.local.entity.PersonWithPayments
import com.hisab.app.data.repository.DashboardSummary
import com.hisab.app.ui.components.MessageComposerDialog
import com.hisab.app.ui.components.PaymentTransactionCard
import com.hisab.app.ui.components.PersonSummaryCard
import com.hisab.app.ui.theme.CollectedGreen
import com.hisab.app.ui.theme.OverdueRed
import com.hisab.app.ui.theme.PendingOrange
import com.hisab.app.ui.theme.WhatsAppGreen
import com.hisab.app.util.DateUtils
import com.hisab.app.util.IndianCurrencyFormatter
import com.hisab.app.util.MessagingHelper
import com.hisab.app.util.MessagingLaunchResult

@Composable
fun DashboardScreen(
    summary: DashboardSummary,
    people: List<PersonWithPayments>,
    recentPayments: List<PaymentWithPerson>,
    currencySymbol: String,
    onPersonClick: (Long) -> Unit,
    onQuickAddPerson: () -> Unit,
    onQuickRecordPayment: () -> Unit,
    onPostMessage: (String) -> Unit
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var reminderTarget by remember { mutableStateOf<Pair<PersonWithPayments, Boolean>?>(null) } // true = WhatsApp, false = SMS

    val pendingPeople = remember(people, searchQuery) {
        val base = people.filter { it.remainingBalancePaise > 0L }
        if (searchQuery.isBlank()) base
        else base.filter {
            it.person.name.contains(searchQuery, ignoreCase = true) ||
                it.person.phoneNumber.contains(searchQuery, ignoreCase = true)
        }
    }

    val overdueOrDueSoon = remember(people) {
        people.filter { it.isOverdue() || it.isDueSoon() }
    }

    val filteredRecentPayments = remember(recentPayments, searchQuery) {
        val base = if (searchQuery.isBlank()) recentPayments else recentPayments.filter {
            it.person.name.contains(searchQuery, ignoreCase = true)
        }
        base.take(5)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search people or phone...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Main Hero Card: Total, Collected, Outstanding
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Total to Collect",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                    Text(
                        text = IndianCurrencyFormatter.formatPaise(summary.totalToCollectPaise, currencySymbol),
                        style = MaterialTheme.typography.headlineLarge,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Collected",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                            Text(
                                text = IndianCurrencyFormatter.formatPaise(summary.totalCollectedPaise, currencySymbol),
                                style = MaterialTheme.typography.titleLarge,
                                color = CollectedGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Outstanding",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                            Text(
                                text = IndianCurrencyFormatter.formatPaise(summary.totalOutstandingPaise, currencySymbol),
                                style = MaterialTheme.typography.titleLarge,
                                color = PendingOrange,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 3 People Count KPIs
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CountKpiCard(
                    label = "Total People",
                    value = summary.totalPeopleCount.toString(),
                    accent = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                CountKpiCard(
                    label = "Pending",
                    value = summary.pendingPeopleCount.toString(),
                    accent = PendingOrange,
                    modifier = Modifier.weight(1f)
                )
                CountKpiCard(
                    label = "Fully Paid",
                    value = summary.fullyPaidPeopleCount.toString(),
                    accent = CollectedGreen,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Quick Actions
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onQuickAddPerson,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Add Person")
                }
                FilledTonalButton(
                    onClick = onQuickRecordPayment,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    enabled = people.any { it.remainingBalancePaise > 0L }
                ) {
                    Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Record Payment")
                }
            }
        }

        // Overdue & Upcoming Reminders
        if (overdueOrDueSoon.isNotEmpty()) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = OverdueRed, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Due & Overdue Reminders", style = MaterialTheme.typography.titleMedium)
                }
            }
            items(overdueOrDueSoon, key = { "due_${it.person.id}" }) { item ->
                val isOverdue = item.isOverdue()
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onPersonClick(item.person.id) },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, if (isOverdue) OverdueRed.copy(alpha = 0.5f) else PendingOrange.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.person.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                text = "${IndianCurrencyFormatter.formatPaise(item.remainingBalancePaise, currencySymbol)} • " +
                                    (if (isOverdue) "Overdue (${DateUtils.formatDate(item.person.dueDateMillis!!)})"
                                    else "Due ${DateUtils.formatDate(item.person.dueDateMillis!!)}"),
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (isOverdue) OverdueRed else PendingOrange
                            )
                        }
                        Row {
                            IconButton(onClick = { reminderTarget = item to true }) {
                                Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = "WhatsApp reminder", tint = WhatsAppGreen)
                            }
                            IconButton(onClick = { reminderTarget = item to false }) {
                                Icon(Icons.Default.Sms, contentDescription = "SMS reminder", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }

        // People with Pending Balances
        item {
            Text("People with Pending Balances (${pendingPeople.size})", style = MaterialTheme.typography.titleMedium)
        }

        if (pendingPeople.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (people.isEmpty()) "No records yet. Tap 'Add Person' to start tracking."
                        else "Everyone has paid in full or no matches found.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(pendingPeople.take(6), key = { it.person.id }) { p ->
                PersonSummaryCard(
                    personWithPayments = p,
                    currencySymbol = currencySymbol,
                    onClick = { onPersonClick(p.person.id) }
                )
            }
        }

        // Recent Payment Activity
        if (filteredRecentPayments.isNotEmpty()) {
            item {
                Text("Recent Payment Activity", style = MaterialTheme.typography.titleMedium)
            }
            items(filteredRecentPayments, key = { "pay_${it.payment.id}" }) { item ->
                PaymentTransactionCard(
                    personName = item.person.name,
                    payment = item.payment,
                    currencySymbol = currencySymbol
                )
            }
        }

        item { Spacer(Modifier.height(72.dp)) }
    }

    reminderTarget?.let { (person, isWhatsApp) ->
        val defaultMsg = remember(person) {
            MessagingHelper.buildReminderMessage(person, currencySymbol)
        }
        MessageComposerDialog(
            title = if (isWhatsApp) "WhatsApp Reminder" else "SMS Reminder",
            initialMessage = defaultMsg,
            actionLabel = if (isWhatsApp) "Open WhatsApp" else "Open SMS",
            onDismiss = { reminderTarget = null },
            onSend = { editedMsg ->
                val result = if (isWhatsApp) {
                    MessagingHelper.openWhatsApp(context, person.person.phoneNumber, editedMsg)
                } else {
                    MessagingHelper.openSms(context, person.person.phoneNumber, editedMsg)
                }
                if (result is MessagingLaunchResult.Error) {
                    onPostMessage(result.message)
                }
                reminderTarget = null
            }
        )
    }
}

@Composable
private fun CountKpiCard(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                color = accent,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

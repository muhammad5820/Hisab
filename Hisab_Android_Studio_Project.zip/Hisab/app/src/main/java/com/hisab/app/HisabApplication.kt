package com.hisab.app

import android.app.Application
import com.hisab.app.data.local.HisabDatabase
import com.hisab.app.data.preferences.AppPreferences
import com.hisab.app.data.repository.HisabRepository
import com.hisab.app.worker.ReminderScheduler

class HisabApplication : Application() {
    val database: HisabDatabase by lazy { HisabDatabase.getInstance(this) }
    val repository: HisabRepository by lazy { HisabRepository(database) }
    val preferences: AppPreferences by lazy { AppPreferences(this) }

    override fun onCreate() {
        super.onCreate()
        ReminderScheduler.ensureNotificationChannel(this)
        ReminderScheduler.scheduleDailyCheck(this)
    }
}

package com.hisab.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.hisab.app.data.local.entity.PaymentEntity
import com.hisab.app.data.local.entity.PaymentMethod
import com.hisab.app.data.local.entity.PaymentWithPerson
import com.hisab.app.data.local.entity.PersonEntity
import com.hisab.app.data.local.entity.PersonWithPayments
import com.hisab.app.data.preferences.AppPreferences
import com.hisab.app.data.preferences.AppSettings
import com.hisab.app.data.preferences.CurrencyDisplayMode
import com.hisab.app.data.preferences.ThemeMode
import com.hisab.app.data.repository.DashboardSummary
import com.hisab.app.data.repository.HisabRepository
import com.hisab.app.data.repository.OperationResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class PeopleSortOption(val label: String) {
    RECENT_ACTIVITY("Recent Activity"),
    NAME_ASC("Name (A-Z)"),
    HIGHEST_BALANCE("Highest Balance"),
    LOWEST_BALANCE("Lowest Balance")
}

enum class PeopleFilterOption(val label: String) {
    ALL("All"),
    PENDING("Pending"),
    PARTIALLY_PAID("Partially Paid"),
    FULLY_PAID("Fully Paid"),
    OVERDUE("Overdue")
}

enum class HistoryDateFilter(val label: String) {
    ALL("All Time"),
    TODAY("Today"),
    THIS_WEEK("This Week"),
    THIS_MONTH("This Month"),
    CUSTOM("Custom Range")
}

class HisabViewModel(
    private val repository: HisabRepository,
    private val preferences: AppPreferences
) : ViewModel() {

    val dashboardSummary: StateFlow<DashboardSummary> = repository.dashboardSummary
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardSummary())

    val allPeople: StateFlow<List<PersonWithPayments>> = repository.allPeopleWithPayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPayments: StateFlow<List<PaymentWithPerson>> = repository.allPaymentsWithPerson
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val appSettings: StateFlow<AppSettings> = preferences.settings

    private val _uiMessages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val uiMessages: SharedFlow<String> = _uiMessages.asSharedFlow()

    fun observePerson(personId: Long): Flow<PersonWithPayments?> = repository.observePerson(personId)

    suspend fun checkDuplicatePhone(phone: String, excludePersonId: Long? = null): PersonEntity? =
        repository.findDuplicatePhonePerson(phone, excludePersonId)

    fun savePerson(
        personId: Long?,
        name: String,
        phoneNumber: String,
        totalAmountPaise: Long,
        createdDateMillis: Long,
        dueDateMillis: Long?,
        notes: String?,
        onSuccess: (Long) -> Unit
    ) {
        viewModelScope.launch {
            if (personId == null) {
                when (val res = repository.addPerson(name, phoneNumber, totalAmountPaise, createdDateMillis, dueDateMillis, notes)) {
                    is OperationResult.Success -> {
                        _uiMessages.tryEmit("Added $name")
                        onSuccess(res.data)
                    }
                    is OperationResult.Error -> _uiMessages.tryEmit(res.message)
                }
            } else {
                when (val res = repository.updatePerson(personId, name, phoneNumber, totalAmountPaise, createdDateMillis, dueDateMillis, notes)) {
                    is OperationResult.Success -> {
                        _uiMessages.tryEmit("Updated $name")
                        onSuccess(personId)
                    }
                    is OperationResult.Error -> _uiMessages.tryEmit(res.message)
                }
            }
        }
    }

    fun deletePerson(person: PersonEntity, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deletePerson(person)
            _uiMessages.tryEmit("Deleted ${person.name}")
            onSuccess()
        }
    }

    fun recordPayment(
        personId: Long,
        amountPaise: Long,
        paymentDateMillis: Long,
        paymentMethod: PaymentMethod,
        transactionReference: String?,
        notes: String?,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            when (val res = repository.recordPayment(personId, amountPaise, paymentDateMillis, paymentMethod, transactionReference, notes)) {
                is OperationResult.Success -> {
                    _uiMessages.tryEmit("Payment recorded")
                    onSuccess()
                }
                is OperationResult.Error -> _uiMessages.tryEmit(res.message)
            }
        }
    }

    fun updatePayment(
        paymentId: Long,
        amountPaise: Long,
        paymentDateMillis: Long,
        paymentMethod: PaymentMethod,
        transactionReference: String?,
        notes: String?,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            when (val res = repository.updatePayment(paymentId, amountPaise, paymentDateMillis, paymentMethod, transactionReference, notes)) {
                is OperationResult.Success -> {
                    _uiMessages.tryEmit("Payment updated")
                    onSuccess()
                }
                is OperationResult.Error -> _uiMessages.tryEmit(res.message)
            }
        }
    }

    fun deletePayment(payment: PaymentEntity, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deletePayment(payment)
            _uiMessages.tryEmit("Payment deleted and balance recalculated")
            onSuccess()
        }
    }

    suspend fun exportBackupJson(): String = repository.exportBackupJson()

    fun restoreBackupJson(json: String) {
        viewModelScope.launch {
            when (val res = repository.restoreFromBackupJson(json)) {
                is OperationResult.Success -> {
                    val (peopleCount, paymentsCount) = res.data
                    _uiMessages.tryEmit("Restored $peopleCount people and $paymentsCount payments")
                }
                is OperationResult.Error -> _uiMessages.tryEmit(res.message)
            }
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.clearAllData()
            _uiMessages.tryEmit("All records cleared")
        }
    }

    fun setThemeMode(mode: ThemeMode) = preferences.setThemeMode(mode)
    fun setCurrencyDisplay(mode: CurrencyDisplayMode) = preferences.setCurrencyDisplay(mode)
    fun setNotificationsEnabled(enabled: Boolean) = preferences.setNotificationsEnabled(enabled)
    fun setPinAndEnableLock(pin: String) {
        preferences.setPinAndEnableLock(pin)
        _uiMessages.tryEmit("App PIN lock enabled")
    }
    fun verifyPin(pin: String): Boolean = preferences.verifyPin(pin)
    fun disableAppLock() {
        preferences.disableAppLock()
        _uiMessages.tryEmit("App lock disabled")
    }
    fun setBiometricEnabled(enabled: Boolean) = preferences.setBiometricEnabled(enabled)

    fun postMessage(msg: String) {
        _uiMessages.tryEmit(msg)
    }

    class Factory(
        private val repository: HisabRepository,
        private val preferences: AppPreferences
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HisabViewModel(repository, preferences) as T
        }
    }
}

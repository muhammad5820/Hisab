package com.hisab.app.data.local.entity

import androidx.room.Embedded
import androidx.room.Relation

enum class PaymentStatus(val label: String) {
    PENDING("Pending"),
    PARTIALLY_PAID("Partially Paid"),
    FULLY_PAID("Fully Paid")
}

data class PersonWithPayments(
    @Embedded val person: PersonEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "personId"
    )
    val payments: List<PaymentEntity>
) {
    val totalPaidPaise: Long
        get() = payments.sumOf { it.amountPaise }

    val remainingBalancePaise: Long
        get() = (person.totalAmountPaise - totalPaidPaise).coerceAtLeast(0L)

    val status: PaymentStatus
        get() = when {
            remainingBalancePaise == 0L -> PaymentStatus.FULLY_PAID
            totalPaidPaise > 0L -> PaymentStatus.PARTIALLY_PAID
            else -> PaymentStatus.PENDING
        }

    val progressFraction: Float
        get() = if (person.totalAmountPaise <= 0L) {
            1f
        } else {
            (totalPaidPaise.toDouble() / person.totalAmountPaise.toDouble())
                .toFloat()
                .coerceIn(0f, 1f)
        }

    val progressPercent: Int
        get() = if (person.totalAmountPaise <= 0L) {
            100
        } else {
            ((totalPaidPaise * 100L) / person.totalAmountPaise).toInt().coerceIn(0, 100)
        }

    val lastActivityMillis: Long
        get() = maxOf(
            person.updatedAtMillis,
            payments.maxOfOrNull { it.paymentDateMillis } ?: person.createdDateMillis
        )

    fun isOverdue(nowMillis: Long = System.currentTimeMillis()): Boolean {
        val due = person.dueDateMillis ?: return false
        return remainingBalancePaise > 0L && due < startOfDayMillis(nowMillis)
    }

    fun isDueSoon(nowMillis: Long = System.currentTimeMillis(), daysAhead: Int = 3): Boolean {
        val due = person.dueDateMillis ?: return false
        if (remainingBalancePaise <= 0L) return false
        val startToday = startOfDayMillis(nowMillis)
        val horizon = startToday + daysAhead * 24L * 60L * 60L * 1000L
        return due in startToday..horizon
    }

    companion object {
        private fun startOfDayMillis(timeMillis: Long): Long {
            val cal = java.util.Calendar.getInstance().apply {
                timeInMillis = timeMillis
                set(java.util.Calendar.HOUR_OF_DAY, 0)
                set(java.util.Calendar.MINUTE, 0)
                set(java.util.Calendar.SECOND, 0)
                set(java.util.Calendar.MILLISECOND, 0)
            }
            return cal.timeInMillis
        }
    }
}

data class PaymentWithPerson(
    @Embedded val payment: PaymentEntity,
    @Relation(
        parentColumn = "personId",
        entityColumn = "id"
    )
    val person: PersonEntity
)

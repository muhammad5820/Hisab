package com.hisab.app.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.hisab.app.data.local.entity.PaymentEntity
import com.hisab.app.data.local.entity.PaymentWithPerson
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentDao {

    @Transaction
    @Query("SELECT * FROM payments ORDER BY paymentDateMillis DESC, createdAtMillis DESC")
    fun observeAllPaymentsWithPerson(): Flow<List<PaymentWithPerson>>

    @Query("SELECT * FROM payments ORDER BY paymentDateMillis DESC, createdAtMillis DESC")
    suspend fun getAllPaymentsOnce(): List<PaymentEntity>

    @Query("SELECT * FROM payments WHERE personId = :personId ORDER BY paymentDateMillis DESC, createdAtMillis DESC")
    fun observePaymentsForPerson(personId: Long): Flow<List<PaymentEntity>>

    @Query("SELECT * FROM payments WHERE id = :paymentId")
    suspend fun getPaymentById(paymentId: Long): PaymentEntity?

    @Query("SELECT COALESCE(SUM(amountPaise), 0) FROM payments WHERE personId = :personId")
    suspend fun getTotalPaidForPerson(personId: Long): Long

    @Query("SELECT COALESCE(SUM(amountPaise), 0) FROM payments WHERE personId = :personId AND id != :excludePaymentId")
    suspend fun getTotalPaidExcluding(personId: Long, excludePaymentId: Long): Long

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertPayment(payment: PaymentEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(payments: List<PaymentEntity>)

    @Update
    suspend fun updatePayment(payment: PaymentEntity)

    @Delete
    suspend fun deletePayment(payment: PaymentEntity)

    @Query("DELETE FROM payments")
    suspend fun deleteAll()
}

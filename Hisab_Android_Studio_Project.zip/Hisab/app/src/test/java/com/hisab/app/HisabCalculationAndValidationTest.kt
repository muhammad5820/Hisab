package com.hisab.app

import com.hisab.app.data.local.entity.PaymentEntity
import com.hisab.app.data.local.entity.PaymentMethod
import com.hisab.app.data.local.entity.PaymentStatus
import com.hisab.app.data.local.entity.PersonEntity
import com.hisab.app.data.local.entity.PersonWithPayments
import com.hisab.app.util.IndianCurrencyFormatter
import com.hisab.app.util.MessagingHelper
import com.hisab.app.util.PhoneNumberHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HisabCalculationAndValidationTest {

    private fun person(name: String = "Rahul", totalRupees: Long): PersonEntity =
        PersonEntity(
            id = 1L,
            name = name,
            phoneNumber = "9876543210",
            totalAmountPaise = totalRupees * 100L,
            createdDateMillis = 1_700_000_000_000L
        )

    private fun payment(id: Long, rupees: Long): PaymentEntity =
        PaymentEntity(
            id = id,
            personId = 1L,
            amountPaise = rupees * 100L,
            paymentDateMillis = 1_700_086_400_000L,
            paymentMethod = PaymentMethod.UPI
        )

    @Test
    fun scenarioA_singlePartialPayment_calculatesRemaining8000() {
        val record = PersonWithPayments(
            person = person(totalRupees = 10_000L),
            payments = listOf(payment(1L, 2_000L))
        )
        assertEquals(200_000L, record.totalPaidPaise)
        assertEquals(800_000L, record.remainingBalancePaise)
        assertEquals(PaymentStatus.PARTIALLY_PAID, record.status)
        assertEquals("₹8,000", IndianCurrencyFormatter.formatPaise(record.remainingBalancePaise))
    }

    @Test
    fun scenarioB_multiplePayments_calculatesRemaining4000() {
        val record = PersonWithPayments(
            person = person(totalRupees = 10_000L),
            payments = listOf(
                payment(1L, 2_000L),
                payment(2L, 3_000L),
                payment(3L, 1_000L)
            )
        )
        assertEquals(600_000L, record.totalPaidPaise)
        assertEquals(400_000L, record.remainingBalancePaise)
        assertEquals(60, record.progressPercent)
        assertEquals("₹4,000", IndianCurrencyFormatter.formatPaise(record.remainingBalancePaise))
    }

    @Test
    fun scenarioC_fullPayment_marksFullyPaidWithZeroRemaining() {
        val record = PersonWithPayments(
            person = person(totalRupees = 5_000L),
            payments = listOf(payment(1L, 5_000L))
        )
        assertEquals(0L, record.remainingBalancePaise)
        assertEquals(PaymentStatus.FULLY_PAID, record.status)
        assertEquals(100, record.progressPercent)
        assertEquals("₹0", IndianCurrencyFormatter.formatPaise(record.remainingBalancePaise))
    }

    @Test
    fun scenarioD_afterDeleting2000Payment_recalculatesRemaining7000() {
        val initialPayments = listOf(payment(1L, 2_000L), payment(2L, 3_000L))
        val afterDeletion = initialPayments.filterNot { it.id == 1L }
        val record = PersonWithPayments(
            person = person(totalRupees = 10_000L),
            payments = afterDeletion
        )
        assertEquals(300_000L, record.totalPaidPaise)
        assertEquals(700_000L, record.remainingBalancePaise)
        assertEquals("₹7,000", IndianCurrencyFormatter.formatPaise(record.remainingBalancePaise))
    }

    @Test
    fun indianCurrencyFormatter_formatsLakhsAndCroresAccurately() {
        assertEquals("₹1,00,000", IndianCurrencyFormatter.formatPaise(100_000_00L))
        assertEquals("₹12,34,567", IndianCurrencyFormatter.formatPaise(1_234_567_00L))
        assertEquals("₹1,500.50", IndianCurrencyFormatter.formatPaise(150_050L))
        assertEquals("₹0", IndianCurrencyFormatter.formatPaise(0L))
    }

    @Test
    fun parseRupeesToPaise_avoidsFloatingPointErrorsAndRejectsInvalid() {
        assertEquals(1000_00L, IndianCurrencyFormatter.parseRupeesToPaise("1,000"))
        assertEquals(1234_56L, IndianCurrencyFormatter.parseRupeesToPaise("₹1,234.56"))
        assertNull(IndianCurrencyFormatter.parseRupeesToPaise("-500"))
        assertNull(IndianCurrencyFormatter.parseRupeesToPaise("12.345"))
        assertNull(IndianCurrencyFormatter.parseRupeesToPaise(""))
    }

    @Test
    fun phoneNumberHelper_normalizesIndianNumbers() {
        assertEquals("919876543210", PhoneNumberHelper.toWhatsAppDigits("9876543210"))
        assertEquals("919876543210", PhoneNumberHelper.toWhatsAppDigits("+91 98765 43210"))
        assertEquals("919876543210", PhoneNumberHelper.toWhatsAppDigits("09876543210"))
        assertEquals("9876543210", PhoneNumberHelper.canonicalKey("+91-9876543210"))
    }

    @Test
    fun messagingHelper_generatesExpectedReminderTemplate() {
        val record = PersonWithPayments(
            person = person(name = "Rahul", totalRupees = 10_000L),
            payments = listOf(payment(1L, 6_000L))
        )
        val msg = MessagingHelper.buildReminderMessage(record)
        assertTrue(msg.contains("Hello Rahul,"))
        assertTrue(msg.contains("Total Amount: ₹10,000"))
        assertTrue(msg.contains("Amount Paid: ₹6,000"))
        assertTrue(msg.contains("Remaining Balance: ₹4,000"))
    }
}
